import { spawnSync } from 'node:child_process';
import { existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { defineConfig, loadEnv } from 'vite';

const externalPackages = [
  '@babylonjs/core',
  'nanostores',
  'pixi-filters',
  'pixi.js',
  'three'
];

function readBoolean(value, fallback = false) {
  if (value == null || value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());
}

function isExternalRuntimePackage(id) {
  return externalPackages.some((pkg) => id === pkg || id.startsWith(`${pkg}/`))
    || id.startsWith('@babylonjs/')
    || id.startsWith('@pixi/');
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const isProduction = mode === 'production' || process.env.NODE_ENV === 'production';
  const buildTimestamp = new Date().toISOString();
  const banner = `/*! OmniCore | author=OmniCore Open Engine Maintainers | built=${buildTimestamp} | proof=OmniCore.Genealogy() */`;
  const sourceMapEnabled = readBoolean(env.OMNICORE_SOURCEMAP, !isProduction);
  const outputMinify = isProduction
    ? {
      compress: {
        dropConsole: true,
        dropDebugger: true
      },
      mangle: true,
      codegen: false
    }
    : false;

  const config = {
    root: '.',
    plugins: [leanCoreBuildPlugin(isProduction)],
    define: {
      __OMNICORE_DEV__: JSON.stringify(!isProduction),
      __OMNICORE_MODE__: JSON.stringify(mode),
      __OMNICORE_SOURCEMAP__: JSON.stringify(!isProduction && sourceMapEnabled)
    },
    build: {
      lib: {
        entry: 'src/index.js',
        name: 'OmniCore',
        formats: ['es', 'iife'],
        fileName: (format) => (format === 'iife' ? 'omnicore.iife.js' : 'omnicore.js')
      },
      minify: isProduction ? 'oxc' : false,
      sourcemap: isProduction ? false : sourceMapEnabled,
      rolldownOptions: {
        external: isExternalRuntimePackage,
        output: {
          banner,
          exports: 'named',
          minify: outputMinify,
          globals: {
            '@babylonjs/core': 'BABYLON',
            nanostores: 'nanostores',
            'pixi-filters': 'PixiFilters',
            'pixi.js': 'PIXI',
            three: 'THREE'
          }
        }
      }
    },
    test: {
      environment: 'jsdom',
      setupFiles: ['tests/setup.js'],
      globals: true,
      coverage: {
        provider: 'v8'
      }
    }
  };

  return config;
});

function leanCoreBuildPlugin(enabled) {
  return {
    name: 'omnicore-lean-core-build',
    closeBundle() {
      if (!enabled || process.env.OMNICORE_SKIP_LEAN_BUILD === '1') return;
      const env = { ...process.env, OMNICORE_SKIP_LEAN_BUILD: '1' };
      const result = process.platform === 'win32'
        ? spawnSync('cmd.exe', ['/d', '/s', '/c', 'npx vite build --config vite.lean.config.js --mode production'], { stdio: 'inherit', env })
        : spawnSync('npx', ['vite', 'build', '--config', 'vite.lean.config.js', '--mode', 'production'], { stdio: 'inherit', env });
      if (result.status !== 0) throw new Error('Lean core build failed.');
      const coreFile = path.resolve('dist/omnicore-core.js');
      if (!existsSync(coreFile)) throw new Error('Lean core build did not emit dist/omnicore-core.js.');
      const size = statSync(coreFile).size;
      console.log(`[OmniCore] lean core ESM size: ${size} bytes`);
      if (size > 40 * 1024) throw new Error('Lean core ESM exceeds 40KB budget.');
    }
  };
}
