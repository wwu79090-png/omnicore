/**
 * Debug object tree editor for scene entities.
 */
export class LiveInspector {
  constructor(game, { edge = 'right' } = {}) {
    this.game = game;
    this.edge = edge;
    this.panel = null;
    this.selected = null;
  }

  attach() {
    if (typeof document === 'undefined' || this.panel) return;
    this.panel = document.createElement('div');
    this.panel.dataset.omnicoreLiveInspector = 'true';
    Object.assign(this.panel.style, {
      position: 'fixed',
      top: '48px',
      [this.edge]: '8px',
      width: '220px',
      maxHeight: '70vh',
      overflow: 'auto',
      background: 'rgba(15,23,42,0.74)',
      color: '#e2e8f0',
      zIndex: '2147483646',
      padding: '8px',
      font: '12px monospace',
      border: '1px solid rgba(148,163,184,0.4)'
    });
    document.body.appendChild(this.panel);
    this.refresh();
  }

  refresh() {
    if (!this.panel) return;
    this.panel.innerHTML = '<strong>Entities</strong>';
    const children = this.game?.scene?.current?.children || [];
    children.forEach((entity, index) => {
      const row = document.createElement('button');
      row.type = 'button';
      row.textContent = `${entity.name || entity.texture || entity.type || 'entity'} @ ${Math.round(entity.x || 0)},${Math.round(entity.y || 0)}`;
      Object.assign(row.style, {
        display: 'block',
        width: '100%',
        marginTop: '6px',
        textAlign: 'left',
        color: '#e2e8f0',
        background: 'rgba(30,41,59,0.8)',
        border: '1px solid rgba(148,163,184,0.28)'
      });
      row.addEventListener('click', () => this._select(entity, index));
      this.panel.appendChild(row);
    });
  }

  detach() {
    this.panel?.remove?.();
    this.panel = null;
  }

  _select(entity) {
    this.selected = entity;
    const controls = document.createElement('div');
    controls.innerHTML = ['x', 'y', 'scaleX', 'scaleY'].map((key) => `
      <label style="display:block;margin-top:6px">${key}
        <input data-key="${key}" type="number" value="${entity[key] ?? (key.startsWith('scale') ? 1 : 0)}" style="width:80px" />
      </label>
    `).join('');
    controls.querySelectorAll('input').forEach((input) => {
      input.addEventListener('input', () => {
        entity[input.dataset.key] = Number(input.value);
        this.game?.renderer?.renderScene?.(this.game.scene?.current);
        this.refresh();
      });
    });
    this.panel.appendChild(controls);
  }
}

export default LiveInspector;
