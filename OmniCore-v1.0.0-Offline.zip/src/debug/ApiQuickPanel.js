const METHODS = [
  'new OmniCore.Game(config)',
  'new OmniCore.Scene(name)',
  'scene.add(sprite)',
  'new OmniCore.Sprite(texture, options)',
  'new OmniCore.Tween(target, config)',
  'OmniCore.Backend.switch("canvas")',
  'game.scene.push("play")',
  'game.scene.pop()',
  'game.input.keyboard.isDown("KeyA")',
  'game.input.pointer.on("click", fn)',
  'scene.camera.follow(target)',
  'scene.timer.delay(ms, fn)',
  'OmniCore.DB.get("items", "potion")',
  'renderer.drawRect({ x, y, width, height })',
  'Store.get("score")'
];

export class ApiQuickPanel {
  constructor() {
    this.panel = null;
    this.boundKey = (event) => {
      if (event.key === 'F1') {
        event.preventDefault();
        this.toggle();
      }
    };
  }

  attach() {
    if (typeof window === 'undefined') return;
    window.addEventListener('keydown', this.boundKey);
  }

  toggle() {
    if (this.panel) {
      this.detachPanel();
      return;
    }
    this.panel = document.createElement('div');
    this.panel.dataset.omnicoreApiPanel = 'true';
    this.panel.innerHTML = `<strong>OmniCore API</strong><ol>${METHODS.map((item) => `<li><code>${item}</code></li>`).join('')}</ol>`;
    Object.assign(this.panel.style, {
      position: 'fixed',
      left: '50%',
      top: '50%',
      transform: 'translate(-50%, -50%)',
      width: '520px',
      maxWidth: '90vw',
      padding: '16px',
      color: '#e2e8f0',
      background: 'rgba(15,23,42,0.9)',
      border: '1px solid #38bdf8',
      zIndex: '2147483647',
      font: '13px monospace'
    });
    document.body.appendChild(this.panel);
  }

  detachPanel() {
    this.panel?.remove?.();
    this.panel = null;
  }

  detach() {
    if (typeof window !== 'undefined') window.removeEventListener('keydown', this.boundKey);
    this.detachPanel();
  }
}

export default ApiQuickPanel;
