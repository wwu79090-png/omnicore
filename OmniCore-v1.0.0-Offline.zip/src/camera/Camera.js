/**
 * 2D camera utility with follow, zoom, and shake.
 *
 * The camera is available as `game.camera` and injected into scenes as
 * `scene.camera`.
 *
 * @example
 * scene.camera.follow(player, { lerp: 0.2 });
 * scene.camera.zoom(1.5);
 * scene.camera.shake(180, 8);
 */
export class Camera {
  constructor({ x = 0, y = 0, zoom = 1 } = {}) {
    this.x = x;
    this.y = y;
    this.zoomLevel = zoom;
    this.target = null;
    this.followLerp = 1;
    this.offsetX = 0;
    this.offsetY = 0;
    this.shakeRemaining = 0;
    this.shakeIntensity = 0;
  }

  follow(target, { lerp = 1 } = {}) {
    this.target = target;
    this.followLerp = Math.max(0, Math.min(1, lerp));
    return this;
  }

  zoom(value) {
    this.zoomLevel = Math.max(0.01, Number(value));
    return this;
  }

  shake(duration = 120, intensity = 4) {
    this.shakeRemaining = Math.max(0, duration);
    this.shakeIntensity = Math.max(0, intensity);
    return this;
  }

  update(delta) {
    const deltaMs = delta <= 10 ? delta * 1000 : delta;
    if (this.target) {
      this.x += (this.target.x - this.x) * this.followLerp;
      this.y += (this.target.y - this.y) * this.followLerp;
    }

    if (this.shakeRemaining > 0) {
      this.shakeRemaining = Math.max(0, this.shakeRemaining - deltaMs);
      this.offsetX = (Math.random() * 2 - 1) * this.shakeIntensity;
      this.offsetY = (Math.random() * 2 - 1) * this.shakeIntensity;
    } else {
      this.offsetX = 0;
      this.offsetY = 0;
    }

    return this;
  }

  reset() {
    this.x = 0;
    this.y = 0;
    this.zoomLevel = 1;
    this.target = null;
    this.offsetX = 0;
    this.offsetY = 0;
    this.shakeRemaining = 0;
    this.shakeIntensity = 0;
  }
}

export default Camera;
