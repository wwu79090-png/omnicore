import {
  createCanvas,
  detectEnvironment,
  normalizeConfig,
  removeContainerCanvases,
  resolveContainer,
  safeInitialize
} from './Bootstrap.js';
import EventBus from './EventBus.js';
import Logger from './Logger.js';
import PixiRenderer from '../renderer/PixiRenderer.js';
import RendererManager from '../renderer/RendererManager.js';
import WebGLContextManager from '../renderer/WebGLContextManager.js';
import Loop from '../loop/Loop.js';
import SceneManager from '../scene/SceneManager.js';
import Store from '../store/Store.js';
import Loader from '../loader/Loader.js';
import AssetLoader from '../loader/AssetLoader.js';
import { DB, Database } from '../database/Database.js';
import Inspector from '../debug/Inspector.js';
import PerformanceMonitor from '../debug/PerformanceMonitor.js';
import PlatformAdapter from '../platform/PlatformAdapter.js';
import Dimension3D from '../dimension3d/Dimension3D.js';
import AudioManager from '../audio/AudioManager.js';
import NetManager, { StorageManager } from '../net/NetManager.js';
import AuthManager from '../compliance/AuthManager.js';
import InputManager from '../input/InputManager.js';
import Camera from '../camera/Camera.js';
import Timer from '../timer/Timer.js';
import Deprecation from './Deprecation.js';
import HotReload from '../hotreload/HotReload.js';
import AIImporter from '../importer/AIImporter.js';
import WorkerManager from '../worker/WorkerManager.js';

/**
 * OmniCore.Game and core runtime composition.
 *
 * Owns WebGL/Canvas context management, automatic fallback, autoResize,
 * module wiring, debug lookup, platform adapters, and experimental renderer
 * backend switching.
 *
 * @example
 * const game = new OmniCore.Game({
 *   width: 960,
 *   height: 540,
 *   renderer: 'pixi',
 *   platform: 'web',
 *   debug: true
 * });
 * await game.init();
 * await OmniCore.Backend.switch('canvas'); // experimental
 */
class CoreContext {
  constructor(config) {
    this.config = config;
    this.canvas = null;
    this.container = null;
    this.resizeHandler = null;
  }

  init() {
    this.canvas = createCanvas(this.config.width, this.config.height, this.config.canvas);
    this.container = resolveContainer(this.config.parent || this.config.container);
    this.attachCanvas();
    return this.canvas;
  }

  attachCanvas() {
    if (this.config.autoAttach && this.container && !this.canvas.parentNode) {
      this.container.appendChild(this.canvas);
    }
  }

  recreateCanvas() {
    this.canvas = createCanvas(this.config.width, this.config.height);
    this.attachCanvas();
    return this.canvas;
  }

  detectContext(preferred = 'webgl') {
    if (preferred === 'auto') return 'auto';
    if (preferred === 'canvas') return 'canvas';
    try {
      const gl = this.canvas.getContext?.('webgl2') || this.canvas.getContext?.('webgl');
      return gl ? preferred : 'canvas';
    } catch {
      return 'canvas';
    }
  }

  autoResize(rendererOrGetter) {
    if (!this.config.autoResize || typeof window === 'undefined') return;
    this.resizeHandler = () => {
      const width = this.container?.clientWidth || this.config.width;
      const height = this.container?.clientHeight || this.config.height;
      const renderer = typeof rendererOrGetter === 'function' ? rendererOrGetter() : rendererOrGetter;
      renderer?.resize?.(width, height);
    };
    window.addEventListener('resize', this.resizeHandler);
  }

  resetWebGLState() {
    try {
      const gl = this.canvas?.getContext?.('webgl') || this.canvas?.getContext?.('webgl2');
      gl?.getExtension?.('WEBGL_lose_context')?.loseContext?.();
    } catch {
      // WebGL context reset is best-effort across browsers and test runtimes.
    }
  }

  clearContainerCanvases() {
    removeContainerCanvases(this.container);
  }

  destroy() {
    if (this.resizeHandler && typeof window !== 'undefined') {
      window.removeEventListener('resize', this.resizeHandler);
    }
    this.resetWebGLState();
    if (this.canvas?.parentNode) this.canvas.parentNode.removeChild(this.canvas);
    this.canvas = null;
    this.container = null;
    this.resizeHandler = null;
  }
}

export class BackendManager {
  constructor(game) {
    this.game = game;
    this.switching = false;
  }

  async switch(backend) {
    if (!['pixi', 'canvas', 'webgl', 'auto'].includes(backend)) {
      throw new Error(`Unsupported renderer backend: ${backend}`);
    }
    if (this.switching) return this.game.renderer;
    this.switching = true;

    try {
      this.game.hooks?.switchStart?.(backend, this.game);
      this.game.events?.emit?.('switchStart', { backend });
      this.game.store?.set?.('switching', true);
      const wasRunning = this.game.loop?.running && !this.game.loop?.paused;
      this.game.loop?.pause?.();
      this.game.renderer?.destroy?.();
      this.game.core?.resetWebGLState?.();
      this.game.core?.clearContainerCanvases?.();
      const canvas = this.game.core?.recreateCanvas?.();
      if (canvas && this.game.input) this.game.input.bind(canvas);
      if (canvas) this.game.webglContext?.bind?.(canvas);
      this.game.renderer = backend === 'auto'
        ? await this.game.rendererManager.create('auto')
        : await this.game.createRenderer(backend);
      this.game.store?.injectBackend?.(this.game.renderer?.backend || backend);
      this.game.renderer?.renderScene?.(this.game.scene?.current);
      this.game.store?.set?.('switching', false);
      this.game.hooks?.switchComplete?.(this.game.renderer?.backend || backend, this.game);
      this.game.events?.emit?.('switchComplete', { backend: this.game.renderer?.backend || backend });
      if (wasRunning) this.game.loop?.resume?.();
      return this.game.renderer;
    } finally {
      this.switching = false;
      this.game.store?.set?.('switching', false);
    }
  }

  async use(backend) {
    const entry = Deprecation.find('OmniCore.Backend.use');
    return Deprecation.forward({
      ...entry,
      target: () => this.switch(backend)
    });
  }
}

export const Backend = {
  game: null,
  bind(game) {
    this.game = game;
    return this;
  },
  async switch(backend) {
    if (!this.game) throw new Error('OmniCore.Backend.switch requires an initialized Game.');
    return this.game.backend.switch(backend);
  },
  async use(backend) {
    const entry = Deprecation.find('OmniCore.Backend.use');
    return Deprecation.forward({
      ...entry,
      target: () => Backend.switch(backend)
    });
  }
};

export async function loadPhysics(loader) {
  if (typeof loader !== 'function') throw new Error('Physics loader must be a function returning an adapter.');
  return loader();
}

export class Game {
  constructor(config = {}) {
    this.config = normalizeConfig(config);
    this.environment = detectEnvironment(globalThis);
    if (!Object.prototype.hasOwnProperty.call(config, 'platform') && this.environment.platform !== 'web') {
      this.config.platform = this.environment.platform;
    }
    this.hooks = {
      onStart: this.config.onStart,
      onPause: this.config.onPause,
      onResume: this.config.onResume,
      onVersionMismatch: this.config.onVersionMismatch,
      switchStart: this.config.switchStart,
      switchComplete: this.config.switchComplete
    };
    this.logger = new Logger({ debug: this.config.debug });
    this.platform = PlatformAdapter.prepare(this.config.platform, this.environment.raw);
    this.events = new EventBus();
    this.timer = new Timer();
    this.core = new CoreContext(this.config);
    this.store = new Store(this.config.state || {});
    this.loader = new Loader({
      fetcher: this.environment.fetcher,
      onFriendlyError: (error) => this.events.emit('loader:error', error)
    });
    this.assetLoader = new AssetLoader({ fetcher: this.environment.fetcher, logger: this.logger });
    this.database = this.config.database instanceof Database ? this.config.database : DB;
    this.rendererManager = new RendererManager({
      createRenderer: (backend, options) => this.createRenderer(backend, options),
      logger: this.logger
    });
    this.loop = new Loop({ fps: 60, autoPause: true });
    this.input = null;
    this.camera = new Camera();
    this.scene = null;
    this.renderer = null;
    this.backend = new BackendManager(this);
    this.audio = new AudioManager();
    this.net = new NetManager({ fetcher: this.environment.fetcher });
    this.storage = StorageManager;
    this.auth = new AuthManager();
    this.worker = new WorkerManager(this.config.worker || {});
    this.aiImporter = new AIImporter({
      ...(this.config.ai || {}),
      fetcher: this.config.ai?.fetcher || this.environment.fetcher,
      injectScene: (sceneJson) => this.events.emit('ai:scene', sceneJson)
    });
    this.hotReload = this.config.hotReload ? new HotReload({
      ...(typeof this.config.hotReload === 'object' ? this.config.hotReload : {}),
      assetLoader: this.assetLoader,
      database: this.database,
      logger: this.logger
    }) : null;
    this.dimension3D = null;
    this.inspector = null;
    this.performanceMonitor = null;
    this.webglContext = null;
    this.microkernelBridge = null;
    this.initialized = false;
    this.destroyed = false;
  }

  async init() {
    await safeInitialize('StorageManager', () => StorageManager.ensureEngineVersion({
      engineVersion: this.config.engineVersion,
      onVersionMismatch: this.hooks.onVersionMismatch,
      migrations: this.config.migrations
    }), null, this.logger);
    await safeInitialize('CoreContext', () => this.core.init(), (error) => {
      throw error;
    }, this.logger);
    if (this.config.microkernel?.enabled) {
      const { default: OmniCoreBridge } = await import('../bridge/OmniCoreBridge.js');
      this.microkernelBridge = new OmniCoreBridge({
        game: this,
        config: this.config.microkernel,
        logger: this.logger
      });
      await this.microkernelBridge.init();
    }
    this._bindWebGLContextManager();
    if (this.config.databaseSources) await this.database.load(this.config.databaseSources);
    const backend = this.config.renderer === 'auto' ? 'auto' : this.core.detectContext(this.config.renderer);
    this.renderer = await safeInitialize(
      'RendererManager',
      () => this.rendererManager.create(backend),
      (error) => this.createRenderer('canvas', { fallbackReason: error }),
      this.logger
    );
    this.core.autoResize(() => this.renderer);
    this.input = safeInitialize('InputManager', () => new InputManager({ target: this.core.canvas }), null, this.logger);
    this.scene = safeInitialize('SceneManager', () => new SceneManager(this), null, this.logger);
    safeInitialize('TimerSubscription', () => this.loop.subscribe((delta) => this.timer.update(delta)), null, this.logger);

    if (this.config.dimension3D && !this.environment.skipThree) {
      this.dimension3D = new Dimension3D(this.config.dimension3D);
      await safeInitialize('Dimension3D', () => this.dimension3D.init(), () => {
        this.dimension3D?.destroy?.();
        this.dimension3D = null;
        return null;
      }, this.logger);
    } else if (this.config.dimension3D && this.environment.skipThree) {
      this.logger.warn('platform', 'Mini-game runtime detected; skipping Three.js/Babylon.js Dimension3D initialization.');
    }

    if (this.config.debug) {
      this.performanceMonitor = safeInitialize(
        'PerformanceMonitor',
        () => new PerformanceMonitor({ debug: true, container: this.core.container }),
        null,
        this.logger
      );
      this.performanceMonitor?.attach?.();
      this.inspector = safeInitialize('Inspector', () => new Inspector(this), null, this.logger);
      this.inspector?.attach?.();
    }

    this.hotReload?.connect?.();

    Backend.bind(this);
    this.initialized = true;
    this.destroyed = false;
    if (this.config.autoStart) this.start();
    return this;
  }

  start() {
    this.loop.start();
    this.hooks.onStart?.(this);
    this.events.emit('start', this);
  }

  pause() {
    this.loop.pause();
    this.hooks.onPause?.(this);
    this.events.emit('pause', this);
  }

  resume() {
    this.loop.resume();
    this.hooks.onResume?.(this);
    this.events.emit('resume', this);
  }

  async createRenderer(backend, options = {}) {
    const renderer = new PixiRenderer({
      backend,
      canvas: this.core.canvas,
      width: this.config.width,
      height: this.config.height,
      background: this.config.background,
      autoResize: this.config.autoResize,
      store: this.store,
      fallbackReason: options.fallbackReason || null
    });
    await renderer.init();
    return renderer;
  }

  destroy() {
    this.loop?.stop?.();
    this.scene?.destroyAll?.();
    this.input?.destroy?.();
    this.renderer?.destroy?.();
    this.microkernelBridge?.destroy?.();
    this.webglContext?.destroy?.();
    this.hotReload?.disconnect?.();
    this.worker?.destroy?.();
    this.dimension3D?.destroy?.();
    this.audio?.stopAll?.();
    this.performanceMonitor?.destroy?.();
    this.inspector?.detach?.();
    this.core?.destroy?.();
    this.events?.clear?.();
    this.initialized = false;
    if (Backend.game === this) Backend.game = null;
    this.renderer = null;
    this.scene = null;
    this.input = null;
    this.webglContext = null;
    this.microkernelBridge = null;
    this.hotReload = null;
    this.dimension3D = null;
    this.performanceMonitor = null;
    this.inspector = null;
    this.destroyed = true;
  }

  _bindWebGLContextManager() {
    const fallback = async () => {
      if (this.destroyed || this.backend.switching || this.renderer?.backend === 'canvas') return;
      await this.backend.switch('canvas');
    };

    if (!this.webglContext) {
      this.webglContext = new WebGLContextManager({
        canvas: this.core.canvas,
        restoreTimeout: this.config.webglRestoreTimeout ?? 2500,
        logger: this.logger,
        onLost: (payload) => this.events.emit('webgl:lost', payload),
        onRestored: (payload) => {
          this.events.emit('webgl:restored', payload);
          this.renderer?.renderScene?.(this.scene?.current);
        },
        onFallback: fallback
      });
      return;
    }

    this.webglContext.bind(this.core.canvas);
  }
}

export { CoreContext, StorageManager };
