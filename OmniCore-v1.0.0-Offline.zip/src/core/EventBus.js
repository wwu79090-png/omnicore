/**
 * Tiny event emitter used by scenes, UI elements, loader, and debug tooling.
 *
 * @example
 * const bus = new EventBus();
 * const off = bus.on('ready', (payload) => console.log(payload));
 * bus.emit('ready', { scene: 'boot' });
 * off();
 */
export class EventBus {
  constructor() {
    this.listeners = new Map();
  }

  on(event, handler) {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    this.listeners.get(event).add(handler);
    return () => this.off(event, handler);
  }

  once(event, handler) {
    const off = this.on(event, (...args) => {
      off();
      handler(...args);
    });
    return off;
  }

  off(event, handler) {
    this.listeners.get(event)?.delete(handler);
  }

  emit(event, payload) {
    for (const handler of this.listeners.get(event) || []) {
      handler(payload);
    }
  }

  clear() {
    this.listeners.clear();
  }
}

export default EventBus;
