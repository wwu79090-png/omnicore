/**
 * Bootstrapping helpers for standard OmniCore configuration and DOM attachment.
 *
 * @example
 * const config = normalizeConfig({ width: 960, height: 540, platform: 'web' });
 * const container = resolveContainer(config.container);
 */
export const STANDARD_DIRECTORIES = [
  'src/core',
  'src/renderer',
  'src/scene',
  'src/loop',
  'src/store',
  'src/loader',
  'src/math',
  'src/audio',
  'src/data',
  'src/net',
  'src/debug',
  'src/pool',
  'src/compliance',
  'src/prefab',
  'src/ui',
  'src/platform',
  'src/dimension3d',
  'tests',
  'examples'
];

export function normalizeConfig(config = {}) {
  return {
    width: 800,
    height: 600,
    renderer: 'pixi',
    platform: 'web',
    parent: null,
    autoResize: true,
    autoStart: true,
    autoAttach: true,
    debug: false,
    background: '#111827',
    manifest: 'asset-manifest.json',
    ...config
  };
}

export function hasDocument() {
  return typeof document !== 'undefined' && typeof document.createElement === 'function';
}

export function resolveContainer(container) {
  if (!hasDocument()) return null;
  if (!container) return document.body;
  if (typeof container === 'string') return document.querySelector(container);
  return container;
}

export function createCanvas(width, height, providedCanvas) {
  const canvas = providedCanvas || (hasDocument() ? document.createElement('canvas') : { style: {} });
  canvas.width = width;
  canvas.height = height;
  canvas.style = canvas.style || {};
  canvas.style.display = 'block';
  canvas.style.touchAction = 'none';
  return canvas;
}

export function removeContainerCanvases(container) {
  if (!container?.querySelectorAll) return;
  container.querySelectorAll('canvas').forEach((canvas) => canvas.remove());
}

export function createNoopCanvasContext() {
  const noop = () => {};
  return {
    canvas: null,
    save: noop,
    restore: noop,
    clearRect: noop,
    fillRect: noop,
    strokeRect: noop,
    beginPath: noop,
    moveTo: noop,
    lineTo: noop,
    quadraticCurveTo: noop,
    closePath: noop,
    fill: noop,
    stroke: noop,
    fillText: noop,
    strokeText: noop,
    drawImage: noop,
    measureText: (text) => ({ width: String(text).length * 8 }),
    setTransform: noop,
    translate: noop,
    rotate: noop,
    scale: noop
  };
}

function createMiniGameResponse(payload) {
  const status = payload.statusCode || payload.status || 200;
  const data = payload.data ?? '';
  const headers = payload.header || payload.headers || {};
  const toText = () => (typeof data === 'string' ? data : JSON.stringify(data));

  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: String(status),
    headers: {
      get: (name) => headers[name] || headers[String(name).toLowerCase()] || ''
    },
    json: async () => (typeof data === 'string' ? JSON.parse(data) : data),
    text: async () => toText(),
    arrayBuffer: async () => {
      if (data instanceof ArrayBuffer) return data;
      if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(toText()).buffer;
      return new ArrayBuffer(0);
    },
    blob: async () => (typeof Blob !== 'undefined' ? new Blob([toText()]) : data)
  };
}

function createMiniGameFetcher(api) {
  return (urlOrRequest, options = {}) => new Promise((resolve, reject) => {
    const url = typeof urlOrRequest === 'string' ? urlOrRequest : urlOrRequest?.url;
    const method = options.method || urlOrRequest?.method || 'GET';
    const headers = options.headers || urlOrRequest?.headers || {};
    const body = options.body ?? urlOrRequest?.body;

    api.request({
      url,
      method,
      header: headers,
      data: body,
      success: (response) => resolve(createMiniGameResponse(response)),
      fail: (error) => reject(error instanceof Error ? error : new Error(error?.errMsg || 'Mini-game request failed'))
    });
  });
}

/**
 * Detects runtime capabilities and returns platform-specific fallbacks.
 *
 * @example
 * const env = detectEnvironment(globalThis);
 * const response = await env.fetcher('/asset-manifest.json');
 */
export function detectEnvironment(env = globalThis) {
  const navigatorRef = env.navigator || {};
  const userAgent = navigatorRef.userAgent || '';
  const wxApi = env.wx;
  const ttApi = env.tt;
  const isWechat = Boolean(wxApi?.request) || /MicroMessenger|MiniGame/i.test(userAgent);
  const isDouyin = Boolean(ttApi?.request) || /ToutiaoMicroApp|Douyin|ByteDance/i.test(userAgent);
  const miniGameApi = wxApi?.request ? wxApi : ttApi?.request ? ttApi : null;
  const isElectron = Boolean(env.process?.versions?.electron) || /Electron/i.test(userAgent);
  const platform = isWechat ? 'wechat' : isDouyin ? 'douyin' : isElectron ? 'electron' : 'web';
  const fetcher = miniGameApi?.request
    ? createMiniGameFetcher(miniGameApi)
    : env.fetch?.bind?.(env) || globalThis.fetch?.bind?.(globalThis);

  return {
    platform,
    runtime: platform,
    isMiniGame: isWechat || isDouyin,
    isWechat,
    isDouyin,
    isElectron,
    isWeb: platform === 'web',
    fetcher,
    request: miniGameApi?.request || null,
    skipThree: isWechat || isDouyin,
    skipBabylon: isWechat || isDouyin,
    skipPixiViewport: isWechat || isDouyin,
    supportsWebGL: !isWechat && !isDouyin,
    raw: env
  };
}

/**
 * Runs a module initializer with a local fallback path.
 *
 * @example
 * const renderer = await safeInitialize('PixiRenderer', () => createPixi(), () => createCanvasRenderer(), logger);
 */
export function safeInitialize(name, initializer, fallback, logger) {
  const fail = (error) => {
    logger?.error?.('bootstrap', `${name} initialization failed`, error);
    if (typeof fallback === 'function') return fallback(error);
    return fallback;
  };

  try {
    const result = initializer();
    if (result && typeof result.then === 'function') {
      return result.catch((error) => fail(error));
    }
    return result;
  } catch (error) {
    return fail(error);
  }
}
