/**
 * Worker task facade with main-thread fallback.
 *
 * @example
 * const worker = new WorkerManager();
 * worker.register('sum', ({ values }) => values.reduce((a, b) => a + b, 0));
 * await worker.run('sum', { values: [1, 2, 3] });
 */
export class WorkerManager {
  constructor({ workerFactory = defaultWorkerFactory } = {}) {
    this.workerFactory = workerFactory;
    this.tasks = new Map();
    this.pending = new Map();
    this.worker = null;
    this.nextId = 1;
  }

  register(name, handler) {
    this.tasks.set(name, handler);
    return this;
  }

  async run(name, payload = {}) {
    const handler = this.tasks.get(name);
    if (!handler) throw new Error(`Worker task "${name}" is not registered.`);
    if (!this.workerFactory) return handler(payload);
    return this._runInWorker(name, payload, handler);
  }

  destroy() {
    const error = new Error('WorkerManager destroyed before task completed.');
    for (const pending of this.pending.values()) pending.reject(error);
    this.pending.clear();
    this.worker?.terminate?.();
    this.worker = null;
  }

  _runInWorker(name, payload, handler) {
    const worker = this._ensureWorker();
    if (!worker || typeof worker.postMessage !== 'function') return Promise.resolve(handler(payload));
    const id = this.nextId;
    this.nextId += 1;

    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject, handler });
      try {
        worker.postMessage({ id, name, payload });
      } catch (error) {
        this.pending.delete(id);
        Promise.resolve()
          .then(() => handler(payload))
          .then(resolve, reject);
      }
    });
  }

  _ensureWorker() {
    if (this.worker) return this.worker;
    try {
      this.worker = this.workerFactory?.();
      if (!this.worker) return null;
      this.worker.onmessage = (event) => {
        const { id, result, error } = event.data || {};
        const pending = this.pending.get(id);
        if (!pending) return;
        this.pending.delete(id);
        if (error) pending.reject(new Error(error));
        else pending.resolve(result);
      };
      this.worker.onerror = (error) => {
        for (const pending of this.pending.values()) pending.reject(error);
        this.pending.clear();
      };
      return this.worker;
    } catch {
      this.worker = null;
      return null;
    }
  }

  static astar({ start, goal, grid }) {
    const key = (point) => `${point.x},${point.y}`;
    const open = [{ ...start, g: 0, f: distance(start, goal), parent: null }];
    const closed = new Set();

    while (open.length) {
      open.sort((a, b) => a.f - b.f);
      const current = open.shift();
      if (current.x === goal.x && current.y === goal.y) return buildPath(current);
      closed.add(key(current));

      for (const next of neighbors(current, grid)) {
        if (closed.has(key(next))) continue;
        const g = current.g + 1;
        const existing = open.find((node) => node.x === next.x && node.y === next.y);
        if (!existing) {
          open.push({ ...next, g, f: g + distance(next, goal), parent: current });
        } else if (g < existing.g) {
          existing.g = g;
          existing.f = g + distance(existing, goal);
          existing.parent = current;
        }
      }
    }

    return [];
  }
}

function defaultWorkerFactory() {
  if (typeof Worker === 'undefined' || typeof Blob === 'undefined' || typeof URL === 'undefined') return null;
  const source = `
    self.onmessage = async (event) => {
      self.postMessage({ id: event.data.id, error: 'No worker task bundle registered.' });
    };
  `;
  return new Worker(URL.createObjectURL(new Blob([source], { type: 'text/javascript' })));
}

function distance(left, right) {
  return Math.abs(left.x - right.x) + Math.abs(left.y - right.y);
}

function neighbors(point, grid) {
  const steps = [
    { x: point.x + 1, y: point.y },
    { x: point.x - 1, y: point.y },
    { x: point.x, y: point.y + 1 },
    { x: point.x, y: point.y - 1 }
  ];
  return steps.filter((item) => grid[item.y]?.[item.x] === 0);
}

function buildPath(node) {
  const path = [];
  let current = node;
  while (current) {
    path.unshift({ x: current.x, y: current.y });
    current = current.parent;
  }
  return path;
}

export default WorkerManager;
