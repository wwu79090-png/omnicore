import PixiRenderer from './PixiRenderer.js';

/**
 * Multi-backend renderer manager with automatic fallback.
 *
 * @example
 * const manager = new RendererManager({ createRenderer });
 * const renderer = await manager.create('auto'); // pixi -> canvas
 */
export class RendererManager {
  constructor({
    createRenderer = null,
    fallbackOrder = ['pixi', 'canvas'],
    logger = null
  } = {}) {
    this.createRenderer = createRenderer || ((backend, options = {}) => new PixiRenderer({ backend, ...options }));
    this.fallbackOrder = fallbackOrder;
    this.logger = logger;
    this.attempts = [];
    this.lastError = null;
  }

  async create(preferred = 'auto', options = {}) {
    const order = preferred === 'auto' ? this.fallbackOrder : [preferred];
    this.attempts = [];
    this.lastError = null;

    for (const backend of order) {
      try {
        this.attempts.push(backend);
        const renderer = await this.createRenderer(backend, options);
        if (renderer?.init && !renderer.app && !renderer.ctx) await renderer.init();
        return renderer;
      } catch (error) {
        this.lastError = error;
        this.logger?.warn?.('renderer', `Renderer backend ${backend} failed; trying fallback.`, error);
      }
    }

    throw this.lastError || new Error(`No renderer backend available for ${preferred}.`);
  }
}

export default RendererManager;
