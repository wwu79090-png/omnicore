import {
  Application,
  Container,
  Graphics,
  Sprite as PixiSprite,
  Text,
  Texture
} from 'pixi.js';
import { appendFilter, createAdjustmentFilter, createBloomFilter, createGlitchFilter } from './Filters.js';
import { createNoopCanvasContext } from '../core/Bootstrap.js';

/**
 * PixiJS v8 backed 2D renderer with Canvas fallback.
 *
 * Pixi lifecycle is sealed behind this wrapper. OmniCore does not expose
 * Pixi's ticker; rendering is driven by OmniCore.Loop.
 *
 * @example
 * const renderer = new PixiRenderer({ backend: 'pixi', canvas, width: 800, height: 600 });
 * await renderer.init();
 * renderer.applyBloom(sprite.displayObject);
 */
export class PixiRenderer {
  constructor({ backend = 'pixi', canvas, width = 800, height = 600, background = '#111827', autoResize = true, store, fallbackReason = null } = {}) {
    this.backend = backend;
    this.canvas = canvas;
    this.width = width;
    this.height = height;
    this.background = background;
    this.autoResize = autoResize;
    this.store = store;
    this.fallbackReason = fallbackReason;
    this.app = null;
    this.stage = null;
    this.ctx = null;
    this.destroyed = false;
  }

  async init() {
    if (this.backend === 'canvas') {
      this.ctx = this._getCanvasContext();
      this.store?.injectBackend(this.backend);
      return this;
    }

    try {
      this.app = new Application();
      await this.app.init({
        canvas: this.canvas,
        width: this.width,
        height: this.height,
        background: this.background,
        preference: 'webgl',
        autoStart: false,
        sharedTicker: false,
        resizeTo: this.autoResize && typeof window !== 'undefined' ? window : undefined
      });
      this.stage = new Container();
      this.app.stage.addChild(this.stage);
      this.canvas = this.app.canvas;
      this.store?.injectBackend(this.backend);
      return this;
    } catch (error) {
      this.backend = 'canvas';
      this.fallbackReason = error;
      this.ctx = this._getCanvasContext();
      this.store?.injectBackend(this.backend);
      this._drawFallbackOverlay();
      return this;
    }
  }

  renderScene(scene) {
    if (!scene) return;
    if (this.backend === 'canvas') {
      this._renderCanvas(scene);
      return;
    }
    this._syncPixiScene(scene);
    this.app?.renderer?.render?.(this.app.stage);
  }

  render(scene) {
    this.renderScene(scene);
  }

  resize(width, height) {
    this.width = width;
    this.height = height;
    if (this.canvas) {
      this.canvas.width = width;
      this.canvas.height = height;
    }
    this.app?.renderer?.resize?.(width, height);
  }

  fade(direction = 'out', duration = 250) {
    return new Promise((resolve) => {
      if (!duration) {
        resolve();
        return;
      }
      setTimeout(resolve, duration);
      this.store?.set('transition', { direction, duration, startedAt: Date.now() });
    });
  }

  applyBloom(target, options = {}) {
    return appendFilter(target, createBloomFilter(options));
  }

  applyGlitch(target, options = {}) {
    return appendFilter(target, createGlitchFilter(options));
  }

  applyAdjustment(target, options = {}) {
    return appendFilter(target, createAdjustmentFilter(options));
  }

  destroy() {
    this.destroyed = true;
    const canvas = this.canvas || this.app?.canvas;
    if (this.app) {
      try {
        this.app.destroy(true, true);
      } catch {
        this.app.destroy(
          { removeView: true },
          { children: true, texture: true, textureSource: true, context: true }
        );
      }
    } else if (this.canvas?.parentNode) {
      this.canvas.parentNode.removeChild(this.canvas);
    }
    if (canvas?.parentNode) canvas.parentNode.removeChild(canvas);
    this.app = null;
    this.stage = null;
    this.ctx = null;
    this.canvas = null;
  }

  _getCanvasContext() {
    try {
      return this.canvas?.getContext?.('2d') || createNoopCanvasContext();
    } catch {
      return createNoopCanvasContext();
    }
  }

  _renderCanvas(scene) {
    const ctx = this.ctx || this._getCanvasContext();
    ctx.clearRect(0, 0, this.width, this.height);
    ctx.fillStyle = this.background;
    ctx.fillRect(0, 0, this.width, this.height);
    for (const child of [...scene.children].sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0))) {
      child.render?.(ctx);
    }
    this._drawFallbackOverlay(ctx);
  }

  _drawFallbackOverlay(ctx = this.ctx) {
    if (!this.fallbackReason || !ctx) return;
    const message = this.fallbackReason?.message || String(this.fallbackReason);
    ctx.save?.();
    ctx.fillStyle = 'rgba(220, 38, 38, 0.32)';
    ctx.fillRect?.(0, 0, this.width, this.height);
    ctx.fillStyle = '#ffffff';
    ctx.font = '14px sans-serif';
    ctx.fillText?.('OmniCore Canvas fallback', 16, 28);
    ctx.fillText?.(message.slice(0, 80), 16, 48);
    ctx.restore?.();
  }

  _syncPixiScene(scene) {
    if (!this.stage) return;
    this.stage.removeChildren();
    for (const child of scene.children) {
      const displayObject = this._ensurePixiDisplayObject(child);
      if (displayObject) this.stage.addChild(displayObject);
    }
  }

  _ensurePixiDisplayObject(child) {
    if (child.displayObject?.destroyed) child.displayObject = null;
    if (child.displayObject) {
      child.syncPixiObject?.(child.displayObject);
      return child.displayObject;
    }
    if (typeof child.toPixiObject === 'function') {
      child.displayObject = child.toPixiObject({ Container, Graphics, Text });
      return child.displayObject;
    }
    if (child.type === 'sprite') {
      const texture = typeof child.texture === 'string' ? Texture.from(child.texture) : Texture.EMPTY;
      const sprite = new PixiSprite(texture);
      this._syncPixiSprite(sprite, child);
      child.displayObject = sprite;
      return sprite;
    }
    return null;
  }

  _syncPixiSprite(sprite, child) {
    sprite.x = child.x;
    sprite.y = child.y;
    sprite.alpha = child.alpha;
    sprite.rotation = child.rotation;
    sprite.scale.set(child.scaleX, child.scaleY);
  }
}

export default PixiRenderer;
