import EventBus from '../core/EventBus.js';

/**
 * Keyboard and pointer input manager.
 *
 * Input is intentionally small and lifecycle-bound to `Game`. Scenes receive
 * `scene.input` automatically, and `SceneManager.update()` refreshes it before
 * calling the active scene update.
 *
 * @example
 * const input = new InputManager({ target: game.core.canvas });
 * input.pointer.on('click', ({ x, y }) => console.log(x, y));
 * if (input.keyboard.isDown('Space')) player.jump();
 */
class KeyboardState {
  constructor() {
    this.keys = new Set();
  }

  isDown(code) {
    return this.keys.has(code);
  }

  press(code) {
    this.keys.add(code);
  }

  release(code) {
    this.keys.delete(code);
  }

  clear() {
    this.keys.clear();
  }
}

class PointerState {
  constructor() {
    this.events = new EventBus();
    this.position = { x: 0, y: 0 };
    this.down = false;
  }

  on(event, handler) {
    return this.events.on(event, handler);
  }

  emit(event, payload) {
    this.events.emit(event, payload);
  }

  clear() {
    this.events.clear();
    this.position = { x: 0, y: 0 };
    this.down = false;
  }
}

export class InputManager {
  constructor({ target = null, preventDefault = true, resolution = null } = {}) {
    this.target = target;
    this.preventDefault = preventDefault;
    this.resolutionOverride = resolution;
    this.resolution = resolution || 1;
    this.keyboard = new KeyboardState();
    this.pointer = new PointerState();
    this.listeners = [];
    this.enabled = true;
    this.bind(target);
  }

  bind(target) {
    this.unbind();
    this.target = target;
    if (!target || typeof window === 'undefined') return;

    this._listen(window, 'keydown', (event) => this.keyboard.press(event.code || event.key));
    this._listen(window, 'keyup', (event) => this.keyboard.release(event.code || event.key));
    this._listen(window, 'resize', () => this.resizeTarget());
    this._listen(target, 'pointermove', (event) => {
      this._prevent(event);
      this._move(event);
      this.pointer.emit('move', this._payload(event));
    }, { passive: false });
    this._listen(target, 'pointerdown', (event) => {
      this._prevent(event);
      this.pointer.down = true;
      this._move(event);
      this.pointer.emit('down', this._payload(event));
    }, { passive: false });
    this._listen(target, 'pointerup', (event) => {
      this._prevent(event);
      this.pointer.down = false;
      this._move(event);
      this.pointer.emit('up', this._payload(event));
    }, { passive: false });
    this._listen(target, 'click', (event) => {
      this._prevent(event);
      this._move(event);
      this.pointer.emit('click', this._payload(event));
    }, { passive: false });
    this.resizeTarget();
  }

  update() {
    return {
      keyboard: this.keyboard,
      pointer: this.pointer
    };
  }

  destroy() {
    this.unbind();
    this.keyboard.clear();
    this.pointer.clear();
    this.enabled = false;
  }

  resizeTarget() {
    if (!this.target) return;
    const rect = this.target.getBoundingClientRect?.() || {};
    const cssWidth = this.target.clientWidth || rect.width || this.target.width || 0;
    const cssHeight = this.target.clientHeight || rect.height || this.target.height || 0;
    const resolution = this.resolutionOverride || window.devicePixelRatio || 1;
    this.resolution = resolution;

    if (cssWidth > 0 && cssHeight > 0) {
      this.target.width = Math.max(1, Math.round(cssWidth * resolution));
      this.target.height = Math.max(1, Math.round(cssHeight * resolution));
      this.target.style.width = `${cssWidth}px`;
      this.target.style.height = `${cssHeight}px`;
    }
  }

  unbind() {
    for (const { target, event, handler, options } of this.listeners) {
      target.removeEventListener?.(event, handler, options);
    }
    this.listeners.length = 0;
  }

  _listen(target, event, handler, options = false) {
    target.addEventListener?.(event, handler, options);
    this.listeners.push({ target, event, handler, options });
  }

  _move(event) {
    const rect = this.target?.getBoundingClientRect?.() || { left: 0, top: 0 };
    this.pointer.position = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    };
  }

  _payload(event) {
    return {
      x: this.pointer.position.x,
      y: this.pointer.position.y,
      originalEvent: event
    };
  }

  _prevent(event) {
    if (this.preventDefault && event.cancelable) event.preventDefault();
  }
}

export default InputManager;
