/**
 * Debug-only visual event graph editor.
 *
 * @example
 * const graph = new VisualEventGraph({ debug: true });
 * graph.addNode({ id: 'check', type: 'condition', data: { op: 'equals' } });
 * graph.exportJSON();
 */
export class VisualEventGraph {
  constructor({ debug = false } = {}) {
    this.debug = debug;
    this.nodes = new Map();
    this.edges = [];
    this.container = null;
    this.root = null;
  }

  addNode(node) {
    const id = node.id || `node-${this.nodes.size + 1}`;
    const normalized = {
      id,
      type: node.type || 'action',
      label: node.label || id,
      x: node.x || 0,
      y: node.y || 0,
      data: node.data || {}
    };
    this.nodes.set(id, normalized);
    this._render();
    return normalized;
  }

  connect(from, to) {
    if (!this.nodes.has(from) || !this.nodes.has(to)) throw new Error('VisualEventGraph.connect requires existing node ids.');
    this.edges.push({ from, to });
    this._render();
    return this;
  }

  attach(container = document.body) {
    if (!this.debug || typeof document === 'undefined') return null;
    this.container = container;
    this.root = document.createElement('div');
    this.root.dataset.omnicoreVisualGraph = 'true';
    Object.assign(this.root.style, {
      position: 'relative',
      minHeight: '220px',
      border: '1px solid #334155',
      background: '#0f172a',
      color: '#e2e8f0',
      font: '12px sans-serif',
      overflow: 'hidden'
    });
    this.container.appendChild(this.root);
    this._render();
    return this.root;
  }

  detach() {
    this.root?.remove?.();
    this.root = null;
    this.container = null;
  }

  exportJSON() {
    return {
      nodes: [...this.nodes.values()].map((node) => ({ ...node, data: { ...node.data } })),
      edges: this.edges.map((edge) => ({ ...edge }))
    };
  }

  toEventSheet() {
    const conditions = [...this.nodes.values()].filter((node) => node.type === 'condition');
    const actions = [...this.nodes.values()].filter((node) => node.type === 'action' || node.type === 'execution');
    return {
      events: conditions.map((condition) => ({
        conditions: [condition.data],
        actions: this.edges
          .filter((edge) => edge.from === condition.id)
          .map((edge) => this.nodes.get(edge.to))
          .filter(Boolean)
          .map((node) => node.data)
      })).concat(conditions.length ? [] : [{ conditions: [], actions: actions.map((node) => node.data) }])
    };
  }

  _render() {
    if (!this.root) return;
    this.root.innerHTML = '';
    for (const node of this.nodes.values()) {
      this.root.appendChild(this._createNodeElement(node));
    }
  }

  _createNodeElement(node) {
    const element = document.createElement('button');
    element.type = 'button';
    element.textContent = node.label;
    element.dataset.nodeId = node.id;
    Object.assign(element.style, {
      position: 'absolute',
      left: `${node.x}px`,
      top: `${node.y}px`,
      minWidth: '96px',
      padding: '8px',
      border: '1px solid #64748b',
      borderRadius: '4px',
      background: node.type === 'condition' ? '#164e63' : '#365314',
      color: '#f8fafc',
      cursor: 'grab'
    });

    let start = null;
    element.addEventListener('pointerdown', (event) => {
      start = { x: event.clientX, y: event.clientY, nodeX: node.x, nodeY: node.y };
      element.setPointerCapture?.(event.pointerId);
    });
    element.addEventListener('pointermove', (event) => {
      if (!start) return;
      node.x = start.nodeX + event.clientX - start.x;
      node.y = start.nodeY + event.clientY - start.y;
      element.style.left = `${node.x}px`;
      element.style.top = `${node.y}px`;
    });
    element.addEventListener('pointerup', () => {
      start = null;
    });
    return element;
  }
}

export default VisualEventGraph;
