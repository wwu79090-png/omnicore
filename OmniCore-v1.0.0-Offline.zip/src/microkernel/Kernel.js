/**
 * Optional microkernel runtime for addon-based extensions.
 *
 * This module is isolated from the legacy `OmniCore.Game` implementation and is
 * only activated through `microkernel.enabled`.
 *
 * @example
 * const kernel = new Kernel();
 * kernel.addon('telemetry', { init() {}, destroy() {} });
 * kernel.use('telemetry');
 */
export class Kernel {
  constructor({
    context = {},
    logger = null,
    debug = false,
    performanceThreshold = 100,
    requestAnimationFrame: raf = globalThis.requestAnimationFrame?.bind(globalThis),
    cancelAnimationFrame: caf = globalThis.cancelAnimationFrame?.bind(globalThis)
  } = {}) {
    this.context = context;
    this.logger = logger;
    this.debug = debug;
    this.performanceThreshold = performanceThreshold;
    this.requestAnimationFrame = raf || ((callback) => setTimeout(() => callback(Date.now()), 16));
    this.cancelAnimationFrame = caf || ((id) => clearTimeout(id));
    this.addons = new Map();
    this.active = {};
    this.state = new Map();
    this.dirty = new Map();
    this.renderers = new Set();
    this.frameHandle = null;
    this.frameDrawInstructions = 0;
    this.flushing = false;
    this.store = {
      set: (key, value) => this.set(key, value),
      get: (key) => this.get(key),
      snapshot: () => this.snapshot()
    };
  }

  addon(name, instance) {
    if (!name) throw new Error('Kernel.addon requires a name.');
    if (!instance) throw new Error(`Kernel.addon "${name}" requires an instance.`);
    if (this.addons.has(name)) {
      this.logger?.warn?.('microkernel', `Addon "${name}" already registered; overwriting.`);
    }
    this.addons.set(name, instance);
    return this;
  }

  use(name, options = {}) {
    if (this.active[name]) return this.active[name];
    const addon = this.addons.get(name);
    if (!addon) throw new Error(`[OmniCore:MicroKernel] Addon "${name}" not found.`);
    addon.init?.(this, options);
    this.active[name] = addon;
    return addon;
  }

  has(name) {
    return this.addons.has(name);
  }

  set(key, value) {
    this.state.set(key, value);
    this.markDirty(key, value);
    return value;
  }

  get(key) {
    return this.state.get(key);
  }

  snapshot() {
    return Object.fromEntries(this.state);
  }

  updateEntity(id, patch = {}) {
    const key = `entity:${id}`;
    const next = { ...(this.state.get(key) || {}), ...patch };
    this.set(key, next);
    return next;
  }

  markDirty(key, value = this.state.get(key)) {
    this.dirty.set(key, value);
    this._scheduleFlush();
  }

  attachRenderer(renderer) {
    if (!renderer) return this;
    this.renderers.add(renderer);
    return this;
  }

  detachRenderer(renderer) {
    this.renderers.delete(renderer);
    return this;
  }

  recordDrawInstruction(count = 1) {
    this.frameDrawInstructions += count;
  }

  async destroy() {
    if (this.frameHandle != null) {
      this.cancelAnimationFrame(this.frameHandle);
      this.frameHandle = null;
    }
    const activeAddons = Object.values(this.active).reverse();
    for (const addon of activeAddons) {
      await addon.destroy?.();
    }
    this.active = {};
    this.addons.clear();
    this.state.clear();
    this.dirty.clear();
    this.renderers.clear();
  }

  _scheduleFlush() {
    if (this.frameHandle != null) return;
    this.frameHandle = this.requestAnimationFrame((time) => this._flushDirty(time));
  }

  _flushDirty(time) {
    this.frameHandle = null;
    if (!this.dirty.size || this.flushing) return;
    this.flushing = true;
    this.frameDrawInstructions = 0;
    const dirty = [...this.dirty.entries()].map(([key, value]) => ({ key, value }));
    this.dirty.clear();
    const payload = { dirty, snapshot: this.snapshot(), kernel: this, time };

    for (const renderer of this.renderers) {
      renderer.renderDirty?.(payload);
    }

    if (this.debug && this.frameDrawInstructions > this.performanceThreshold) {
      this.logger?.warn?.(
        'microkernel',
        `[OmniCore] performance warning: ${this.frameDrawInstructions} draw instructions in one frame.`
      );
    }
    this.flushing = false;
  }
}

export default Kernel;
