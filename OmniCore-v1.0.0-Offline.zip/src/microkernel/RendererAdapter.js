import CanvasRendererAddon from '../addons/CanvasRenderer.js';
import PixiRendererAddon from '../addons/PixiRenderer.js';

/**
 * Renderer abstraction for optional microkernel mode.
 *
 * @example
 * const renderer = new RendererAdapter({ adapter: 'auto' });
 * await renderer.init({ canvas });
 */
export class RendererAdapter {
  constructor({
    adapter = 'auto',
    adapters = {},
    candidates = ['pixi', 'canvas'],
    logger = null,
    config = {}
  } = {}) {
    this.adapter = adapter;
    this.adapters = {
      pixi: (options) => new PixiRendererAddon(options),
      canvas: (options) => new CanvasRendererAddon(options),
      ...adapters
    };
    this.candidates = candidates;
    this.logger = logger;
    this.config = config;
    this.activeBackend = null;
    this.activeBackendName = null;
    this.attempts = [];
    this.lastError = null;
    this.downgraded = false;
  }

  async init(context = {}) {
    const names = this.adapter === 'auto' ? this.candidates : [this.adapter];
    this.attempts = [];
    this.lastError = null;

    for (const name of names) {
      try {
        this.attempts.push(name);
        const backend = await this._createBackend(name, context);
        await backend?.init?.(context);
        if (name === 'canvas' && this.lastError) this._finalizeCanvasFallback(backend, context);
        this.activeBackend = backend;
        this.activeBackendName = backend?.name || name;
        return backend;
      } catch (error) {
        this.lastError = error;
        this.logger?.warn?.('microkernel', `Renderer backend "${name}" failed; trying fallback.`, error);
      }
    }

    throw this.lastError || new Error('[OmniCore:MicroKernel] No renderer backend available.');
  }

  destroy() {
    this.activeBackend?.destroy?.();
    this.activeBackend = null;
    this.activeBackendName = null;
  }

  async _createBackend(name, context) {
    const factory = this.adapters[name];
    if (!factory) throw new Error(`Renderer backend "${name}" is not registered.`);
    const result = typeof factory === 'function'
      ? factory({ ...this.config, ...context, store: context.kernel?.store || context.store, backend: name })
      : factory;
    return result && typeof result.then === 'function' ? result : Promise.resolve(result);
  }

  drawRect(options) {
    return this.activeBackend?.drawRect?.(options);
  }

  drawText(options) {
    return this.activeBackend?.drawText?.(options);
  }

  _finalizeCanvasFallback(backend, context) {
    this.downgraded = true;
    backend.filtersEnabled = false;
    context.kernel?.set?.('renderer:filtersEnabled', false);
    context.store?.set?.('renderer:filtersEnabled', false);
    backend.replayFromStore?.();
  }
}

export default RendererAdapter;
