/**
 * Web Audio wrapper with decoded sound pools.
 *
 * @example
 * const audio = new AudioManager();
 * await audio.load('click', '/audio/click.ogg');
 * audio.play('click', { volume: 0.5 });
 */
export class AudioManager {
  constructor({ context } = {}) {
    this.context = context || null;
    this.buffers = new Map();
    this.active = new Set();
  }

  _ensureContext() {
    if (!this.context && typeof AudioContext !== 'undefined') this.context = new AudioContext();
    return this.context;
  }

  async load(key, url, fetcher = globalThis.fetch?.bind(globalThis)) {
    const context = this._ensureContext();
    if (!context || !fetcher) return null;
    const response = await fetcher(url);
    const data = await response.arrayBuffer();
    const buffer = await context.decodeAudioData(data);
    this.buffers.set(key, buffer);
    return buffer;
  }

  play(key, { volume = 1, loop = false } = {}) {
    const context = this._ensureContext();
    const buffer = this.buffers.get(key);
    if (!context || !buffer) return null;
    const source = context.createBufferSource();
    const gain = context.createGain();
    gain.gain.value = volume;
    source.buffer = buffer;
    source.loop = loop;
    source.connect(gain).connect(context.destination);
    source.start();
    this.active.add(source);
    source.onended = () => this.active.delete(source);
    return source;
  }

  stopAll() {
    for (const source of [...this.active]) source.stop?.();
    this.active.clear();
  }
}

export default AudioManager;
