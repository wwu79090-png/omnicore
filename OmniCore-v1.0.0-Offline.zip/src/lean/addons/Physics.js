/**
 * Lightweight collision addon plus lazy external physics loader.
 */
export class PhysicsAddon {
  mount() {
    return this;
  }

  rectIntersects(a, b) {
    return a.x < b.x + b.width
      && a.x + a.width > b.x
      && a.y < b.y + b.height
      && a.y + a.height > b.y;
  }

  ptInRect(point, rect) {
    return point.x >= rect.x
      && point.x <= rect.x + rect.width
      && point.y >= rect.y
      && point.y <= rect.y + rect.height;
  }

  async loadExternal(loader) {
    if (typeof loader !== 'function') throw new Error('PhysicsAddon.loadExternal requires a loader function.');
    this.external = await loader();
    return this.external;
  }

  unmount() {
    this.external?.destroy?.();
    this.external = null;
  }
}

export default PhysicsAddon;
