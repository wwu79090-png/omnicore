/**
 * Lightweight visual scene editor activated by `OmniCore.Game({ editor: true })`.
 *
 * The editor is isolated in HTML overlays and only talks to the engine through
 * scene children, renderer redraws, and Store synchronization.
 *
 * @example
 * const game = await new OmniCore.Game({ parent: '#game', editor: true }).init();
 * game.editor.exportScene();
 */
export class EditorPlugin {
  constructor(game, options = {}) {
    this.game = game;
    this.options = options;
    this.root = null;
    this.sidebar = null;
    this.entityList = null;
    this.propertyPanel = null;
    this.transformBox = null;
    this.selected = null;
    this.dragging = false;
    this.dragOffset = { x: 0, y: 0 };
    this.listeners = [];
  }

  attach() {
    if (typeof document === 'undefined' || this.root) return this;
    this._createUI();
    this._bindCanvas();
    this.refresh();
    return this;
  }

  refresh() {
    if (!this.root) return;
    this._renderEntityList();
    this._renderProperties();
    this._syncSceneStore();
    this._positionTransformBox();
  }

  select(entity) {
    this.selected = entity || null;
    this.game.store?.set?.('editor:selectedEntity', this._serializeEntity(entity, this._entityIndex(entity)));
    this.refresh();
  }

  exportScene({ download = true } = {}) {
    const payload = this._serializeScene();
    this.game.store?.set?.('editor:lastScene', payload);
    if (download) this._downloadJson(payload);
    return payload;
  }

  saveScene() {
    return this.exportScene({ download: false });
  }

  detach() {
    for (const { target, type, handler, options } of this.listeners) {
      target.removeEventListener?.(type, handler, options);
    }
    this.listeners.length = 0;
    this.root?.remove?.();
    this.transformBox?.remove?.();
    this.root = null;
    this.sidebar = null;
    this.entityList = null;
    this.propertyPanel = null;
    this.transformBox = null;
    this.selected = null;
  }

  _createUI() {
    this.root = document.createElement('section');
    this.root.dataset.omnicoreEditor = 'true';
    Object.assign(this.root.style, {
      position: 'fixed',
      inset: '0',
      pointerEvents: 'none',
      zIndex: '2147483644',
      font: '12px system-ui, sans-serif',
      color: '#e2e8f0'
    });

    this.sidebar = document.createElement('aside');
    Object.assign(this.sidebar.style, {
      position: 'absolute',
      right: '0',
      top: '0',
      width: '280px',
      height: '100%',
      pointerEvents: 'auto',
      boxSizing: 'border-box',
      padding: '12px',
      overflow: 'auto',
      background: 'rgba(15, 23, 42, 0.78)',
      borderLeft: '1px solid rgba(148, 163, 184, 0.45)',
      backdropFilter: 'blur(4px)'
    });

    const actions = document.createElement('div');
    Object.assign(actions.style, { display: 'flex', gap: '8px', marginBottom: '12px' });
    actions.append(
      this._button('保存场景', 'save', () => this.saveScene()),
      this._button('导出为 JSON', 'export', () => this.exportScene())
    );

    const listTitle = document.createElement('h3');
    listTitle.textContent = 'Entity 树';
    const propsTitle = document.createElement('h3');
    propsTitle.textContent = '属性';
    this.entityList = document.createElement('div');
    this.propertyPanel = document.createElement('div');

    this.sidebar.append(actions, listTitle, this.entityList, propsTitle, this.propertyPanel);
    this.root.appendChild(this.sidebar);
    document.body.appendChild(this.root);

    this.transformBox = document.createElement('div');
    this.transformBox.dataset.omnicoreTransformBox = 'true';
    Object.assign(this.transformBox.style, {
      position: 'fixed',
      display: 'none',
      pointerEvents: 'none',
      border: '1px solid rgba(56,189,248,0.95)',
      background: 'rgba(56,189,248,0.14)',
      boxShadow: '0 0 0 1px rgba(15,23,42,0.55) inset',
      zIndex: '2147483643'
    });
    document.body.appendChild(this.transformBox);
  }

  _button(text, action, handler) {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = text;
    button.dataset.editorAction = action;
    Object.assign(button.style, {
      padding: '6px 8px',
      color: '#e2e8f0',
      background: '#0f172a',
      border: '1px solid rgba(56,189,248,0.8)',
      cursor: 'pointer'
    });
    this._listen(button, 'click', handler);
    return button;
  }

  _renderEntityList() {
    if (!this.entityList) return;
    this.entityList.textContent = '';
    const entities = this._entities();
    entities.forEach((entity, index) => {
      const row = document.createElement('button');
      row.type = 'button';
      row.dataset.editorEntityId = String(index);
      row.textContent = entity.name || entity.id || entity.texture || `${entity.type || 'entity'} ${index}`;
      Object.assign(row.style, {
        display: 'block',
        width: '100%',
        marginBottom: '6px',
        padding: '6px',
        textAlign: 'left',
        color: '#e2e8f0',
        background: entity === this.selected ? 'rgba(56,189,248,0.28)' : 'rgba(30,41,59,0.75)',
        border: '1px solid rgba(148,163,184,0.35)',
        cursor: 'pointer'
      });
      this._listen(row, 'click', () => this.select(entity));
      this.entityList.appendChild(row);
    });
  }

  _renderProperties() {
    if (!this.propertyPanel) return;
    this.propertyPanel.textContent = '';
    if (!this.selected) {
      const empty = document.createElement('p');
      empty.textContent = '未选择实体';
      this.propertyPanel.appendChild(empty);
      return;
    }

    [
      ['x', this.selected.x ?? 0],
      ['y', this.selected.y ?? 0],
      ['scale', this.selected.scale ?? this.selected.scaleX ?? 1],
      ['scaleX', this.selected.scaleX ?? this.selected.scale ?? 1],
      ['scaleY', this.selected.scaleY ?? this.selected.scale ?? 1],
      ['rotation', this.selected.rotation ?? 0],
      ['width', this.selected.width ?? 0],
      ['height', this.selected.height ?? 0]
    ].forEach(([key, value]) => {
      const label = document.createElement('label');
      label.textContent = key;
      Object.assign(label.style, { display: 'grid', gap: '4px', marginBottom: '8px' });
      const input = document.createElement('input');
      input.type = 'number';
      input.step = key === 'rotation' ? '0.01' : '1';
      input.value = String(value);
      input.dataset.editorProp = key;
      Object.assign(input.style, {
        width: '100%',
        boxSizing: 'border-box',
        padding: '5px',
        color: '#e2e8f0',
        background: '#020617',
        border: '1px solid rgba(148,163,184,0.5)'
      });
      this._listen(input, 'input', () => this._setSelectedProperty(key, Number(input.value)));
      label.appendChild(input);
      this.propertyPanel.appendChild(label);
    });
  }

  _setSelectedProperty(key, value) {
    if (!this.selected || Number.isNaN(value)) return;
    this.selected[key] = value;
    if (key === 'scale') {
      this.selected.scaleX = value;
      this.selected.scaleY = value;
    }
    this._afterEntityMutation();
  }

  _bindCanvas() {
    const canvas = this.game.core?.canvas || this.game.renderer?.canvas;
    if (!canvas) return;
    this._listen(canvas, 'pointerdown', (event) => this._pointerDown(event), { passive: false });
    this._listen(canvas, 'pointermove', (event) => this._pointerMove(event), { passive: false });
    this._listen(canvas, 'pointerup', (event) => this._pointerUp(event), { passive: false });
    this._listen(canvas, 'pointerleave', (event) => this._pointerUp(event), { passive: false });
  }

  _pointerDown(event) {
    const point = this._canvasPoint(event);
    const entity = this._hitTest(point);
    if (!entity) return;
    event.preventDefault?.();
    this.select(entity);
    this.dragging = true;
    this.dragOffset = {
      x: point.x - (entity.x || 0),
      y: point.y - (entity.y || 0)
    };
  }

  _pointerMove(event) {
    if (!this.dragging || !this.selected) return;
    event.preventDefault?.();
    const point = this._canvasPoint(event);
    this.selected.x = Math.round(point.x - this.dragOffset.x);
    this.selected.y = Math.round(point.y - this.dragOffset.y);
    this._afterEntityMutation();
  }

  _pointerUp() {
    this.dragging = false;
  }

  _afterEntityMutation() {
    this.game.store?.set?.('editor:selectedEntity', this._serializeEntity(this.selected, this._entityIndex(this.selected)));
    this._syncSceneStore();
    this.game.renderer?.renderScene?.(this.game.scene?.current);
    this._renderProperties();
    this._positionTransformBox();
  }

  _hitTest(point) {
    const entities = [...this._entities()].sort((a, b) => (b.zIndex || 0) - (a.zIndex || 0));
    return entities.find((entity) => {
      const scaleX = entity.scale ?? entity.scaleX ?? 1;
      const scaleY = entity.scale ?? entity.scaleY ?? 1;
      const width = (entity.width || 0) * scaleX;
      const height = (entity.height || 0) * scaleY;
      return point.x >= (entity.x || 0)
        && point.x <= (entity.x || 0) + width
        && point.y >= (entity.y || 0)
        && point.y <= (entity.y || 0) + height;
    });
  }

  _canvasPoint(event) {
    const canvas = this.game.core?.canvas || this.game.renderer?.canvas;
    const rect = canvas?.getBoundingClientRect?.() || { left: 0, top: 0, width: canvas?.width || 1, height: canvas?.height || 1 };
    const scaleX = (canvas?.width || rect.width || 1) / (rect.width || canvas?.width || 1);
    const scaleY = (canvas?.height || rect.height || 1) / (rect.height || canvas?.height || 1);
    return {
      x: (event.clientX - rect.left) * scaleX,
      y: (event.clientY - rect.top) * scaleY
    };
  }

  _positionTransformBox() {
    if (!this.transformBox) return;
    if (!this.selected) {
      this.transformBox.style.display = 'none';
      return;
    }
    const canvas = this.game.core?.canvas || this.game.renderer?.canvas;
    const rect = canvas?.getBoundingClientRect?.() || { left: 0, top: 0, width: canvas?.width || 1, height: canvas?.height || 1 };
    const scaleX = (rect.width || canvas?.width || 1) / (canvas?.width || rect.width || 1);
    const scaleY = (rect.height || canvas?.height || 1) / (canvas?.height || rect.height || 1);
    const entityScaleX = this.selected.scale ?? this.selected.scaleX ?? 1;
    const entityScaleY = this.selected.scale ?? this.selected.scaleY ?? 1;
    Object.assign(this.transformBox.style, {
      display: 'block',
      left: `${rect.left + (this.selected.x || 0) * scaleX}px`,
      top: `${rect.top + (this.selected.y || 0) * scaleY}px`,
      width: `${(this.selected.width || 0) * entityScaleX * scaleX}px`,
      height: `${(this.selected.height || 0) * entityScaleY * scaleY}px`,
      transform: `rotate(${this.selected.rotation || 0}rad)`
    });
  }

  _serializeScene() {
    const scene = this.game.scene?.current;
    return {
      format: 'OmniCore.Scene.json',
      version: 1,
      name: scene?.name || 'untitled',
      exportedAt: new Date().toISOString(),
      entities: this._entities().map((entity, index) => this._serializeEntity(entity, index))
    };
  }

  _serializeEntity(entity, index = 0) {
    if (!entity) return null;
    return {
      id: entity.id || entity.name || `entity-${index}`,
      name: entity.name || '',
      type: entity.type || 'entity',
      texture: entity.texture || null,
      x: entity.x ?? 0,
      y: entity.y ?? 0,
      scale: entity.scale ?? entity.scaleX ?? 1,
      scaleX: entity.scaleX ?? entity.scale ?? 1,
      scaleY: entity.scaleY ?? entity.scale ?? 1,
      rotation: entity.rotation ?? 0,
      width: entity.width ?? 0,
      height: entity.height ?? 0,
      alpha: entity.alpha ?? 1,
      zIndex: entity.zIndex ?? 0,
      properties: {
        visible: entity.visible ?? true
      }
    };
  }

  _syncSceneStore() {
    this.game.store?.set?.('editor:scene', this._serializeScene());
  }

  _downloadJson(payload) {
    if (typeof document === 'undefined' || typeof Blob === 'undefined' || !globalThis.URL?.createObjectURL) return;
    const blob = new Blob([`${JSON.stringify(payload, null, 2)}\n`], { type: 'application/json' });
    const url = globalThis.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${payload.name || 'Scene'}.json`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
    globalThis.URL.revokeObjectURL?.(url);
  }

  _entities() {
    return this.game.scene?.current?.children || [];
  }

  _entityIndex(entity) {
    return this._entities().indexOf(entity);
  }

  _listen(target, type, handler, options = false) {
    target.addEventListener?.(type, handler, options);
    this.listeners.push({ target, type, handler, options });
  }
}

export default EditorPlugin;
