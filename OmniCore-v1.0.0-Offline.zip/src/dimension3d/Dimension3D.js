/**
 * Independent 3D rendering layer for Three.js or Babylon.js.
 *
 * This layer owns a separate canvas and lifecycle. Destroying or switching 2D
 * renderers does not mutate Dimension3D.
 *
 * @example
 * const dimension = new Dimension3D({ backend: 'three', canvas });
 * await dimension.init();
 * dimension.render();
 */
export class Dimension3D {
  constructor({ backend = 'three', canvas, width = 800, height = 600 } = {}) {
    this.backend = backend;
    this.canvas = canvas;
    this.width = width;
    this.height = height;
    this.engine = null;
    this.renderer = null;
    this.scene = null;
    this.camera = null;
  }

  async init() {
    if (this.backend === 'babylon') return this._initBabylon();
    return this._initThree();
  }

  async _initThree() {
    const THREE = await import('three');
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(60, this.width / this.height, 0.1, 1000);
    this.camera.position.z = 5;
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true });
    this.renderer.setSize(this.width, this.height, false);
    return this;
  }

  async _initBabylon() {
    const BABYLON = await import('@babylonjs/core');
    this.engine = new BABYLON.Engine(this.canvas, true);
    this.scene = new BABYLON.Scene(this.engine);
    this.camera = new BABYLON.FreeCamera('camera', new BABYLON.Vector3(0, 0, -5), this.scene);
    this.camera.setTarget(BABYLON.Vector3.Zero());
    return this;
  }

  render() {
    if (this.backend === 'babylon') this.scene?.render?.();
    else this.renderer?.render?.(this.scene, this.camera);
  }

  destroy() {
    if (this.backend === 'babylon') {
      this.scene?.dispose?.();
      this.engine?.dispose?.();
    } else {
      this.scene?.traverse?.((object) => {
        object.geometry?.dispose?.();
        if (Array.isArray(object.material)) object.material.forEach((material) => material.dispose?.());
        else object.material?.dispose?.();
      });
      this.renderer?.dispose?.();
    }
    this.engine = null;
    this.renderer = null;
    this.scene = null;
    this.camera = null;
  }
}

export default Dimension3D;
