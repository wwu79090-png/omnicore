/**
 * Network and persistence wrappers.
 *
 * @example
 * const net = new NetManager();
 * const profile = await net.get('/api/profile');
 * StorageManager.set('save', { level: 3 });
 */
export class NetManager {
  constructor({ fetcher = globalThis.fetch?.bind(globalThis), headers = {} } = {}) {
    this.fetcher = fetcher;
    this.headers = headers;
  }

  async request(url, options = {}) {
    if (!this.fetcher) throw new Error('No fetch implementation is available.');
    const response = await this.fetcher(url, {
      ...options,
      headers: { ...this.headers, ...(options.headers || {}) }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status || 500}`);
    const contentType = response.headers?.get?.('content-type') || '';
    return contentType.includes('application/json') ? response.json() : response.text();
  }

  get(url, options = {}) {
    return this.request(url, { ...options, method: 'GET' });
  }

  post(url, body, options = {}) {
    return this.request(url, {
      ...options,
      method: 'POST',
      headers: { 'content-type': 'application/json', ...(options.headers || {}) },
      body: typeof body === 'string' ? body : JSON.stringify(body)
    });
  }
}

export class StorageManager {
  static memory = new Map();

  static engineVersion = '0.1.0';

  static onVersionMismatch = null;

  static migrations = {};

  static configure({ engineVersion, onVersionMismatch, migrations = {} } = {}) {
    if (engineVersion) StorageManager.engineVersion = engineVersion;
    if (onVersionMismatch) StorageManager.onVersionMismatch = onVersionMismatch;
    StorageManager.migrations = { ...StorageManager.migrations, ...migrations };
  }

  static async ensureEngineVersion({ engineVersion, onVersionMismatch, migrations = {} } = {}) {
    StorageManager.configure({ engineVersion, onVersionMismatch, migrations });
    const currentVersion = StorageManager.get('omnicore:engineVersion');
    const targetVersion = StorageManager.engineVersion;

    if (!currentVersion) {
      StorageManager.set('omnicore:engineVersion', targetVersion);
      return { migrated: false, from: null, to: targetVersion };
    }

    if (currentVersion === targetVersion) {
      return { migrated: false, from: currentVersion, to: targetVersion };
    }

    const context = {
      from: currentVersion,
      to: targetVersion,
      storage: StorageManager
    };
    await StorageManager.onVersionMismatch?.(context);
    const migration = StorageManager.migrations[`${currentVersion}->${targetVersion}`];
    if (migration) await migration(context);
    StorageManager.set('omnicore:engineVersion', targetVersion);
    return { migrated: Boolean(migration), from: currentVersion, to: targetVersion };
  }

  static backup(key, value = StorageManager.get(key), version = StorageManager.get('omnicore:engineVersion') || 'unknown') {
    const backupKey = `omnicore:backup:${version}:${key}`;
    if (StorageManager.get(backupKey) === null) StorageManager.set(backupKey, value);
    return backupKey;
  }

  static set(key, value) {
    const serialized = JSON.stringify(value);
    try {
      globalThis.localStorage?.setItem(key, serialized);
    } catch {
      StorageManager.memory.set(key, serialized);
    }
  }

  static get(key, fallback = null) {
    let value = null;
    try {
      value = globalThis.localStorage?.getItem(key);
    } catch {
      value = StorageManager.memory.get(key);
    }
    if (value == null) return fallback;
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  }

  static remove(key) {
    try {
      globalThis.localStorage?.removeItem(key);
    } catch {
      StorageManager.memory.delete(key);
    }
  }

  static read(key, fallback = null) {
    console.warn('[OmniCore] Deprecated API OmniCore.Storage.read since 0.2.0; remove in 1.0.0; use OmniCore.Storage.get.');
    return StorageManager.get(key, fallback);
  }

  static write(key, value) {
    console.warn('[OmniCore] Deprecated API OmniCore.Storage.write since 0.2.0; remove in 1.0.0; use OmniCore.Storage.set.');
    return StorageManager.set(key, value);
  }
}

export default NetManager;
