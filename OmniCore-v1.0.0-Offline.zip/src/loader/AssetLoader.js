import { Assets, Graphics } from 'pixi.js';

/**
 * Defensive image asset loader with missing-texture fallback.
 *
 * Single image failures are converted into a generated Pixi.Graphics square so
 * bundle loading can continue and scenes can still render a visible placeholder.
 *
 * @example
 * const loader = new AssetLoader();
 * const hero = await loader.loadImage({ key: 'hero', url: '/hero.png' });
 * scene.add(new OmniCore.Sprite(hero.texture || hero.displayObject));
 */
export class AssetLoader {
  constructor(options = {}) {
    const {
      assets = Assets,
      fetcher,
      graphicsFactory = null,
      logger = null,
      fallbackColor = 0xff3b30,
      debug = false
    } = options;
    this.assets = assets;
    this.fetcher = fetcher || globalThis.fetch?.bind(globalThis);
    this.preferFetcher = typeof fetcher === 'function';
    this.graphicsFactory = graphicsFactory;
    this.logger = logger;
    this.fallbackColor = fallbackColor;
    this.debug = debug;
    this.cache = new Map();
  }

  async loadImage(item) {
    const normalized = typeof item === 'string' ? { key: item, url: item } : item;
    const key = normalized.key || normalized.url;
    if (this.cache.has(key)) return this.cache.get(key);

    try {
      const texture = await this._loadTexture(normalized);
      const asset = {
        key,
        url: normalized.url,
        texture,
        displayObject: null,
        fallback: false,
        error: null
      };
      this.cache.set(key, asset);
      return asset;
    } catch (error) {
      const asset = this._createMissingTexture(normalized, error);
      this.cache.set(key, asset);
      this.logger?.warn?.('loader', `Image ${key} failed; generated fallback texture.`, error);
      return asset;
    }
  }

  async loadImages(items = []) {
    const output = {};
    await Promise.all(items.map(async (item) => {
      const asset = await this.loadImage(item);
      output[asset.key] = asset;
    }));
    return output;
  }

  clear() {
    this.cache.clear();
  }

  async _loadTexture(item) {
    if (item.texture) return item.texture;
    if (!item.url) throw new Error('Image item requires a url.');
    if (this.preferFetcher) return this._fetchImage(item);
    if (this.assets?.load) return this.assets.load(item.url);
    return this._fetchImage(item);
  }

  async _fetchImage(item) {
    if (!this.fetcher) throw new Error('No asset loader is available.');

    const response = await this.fetcher(item.url);
    if (!response.ok) throw new Error(`HTTP ${response.status || 500}`);
    return response.blob ? response.blob() : response;
  }

  _createMissingTexture(item, error) {
    const width = item.width || 32;
    const height = item.height || 32;
    const displayObject = this._createFallbackGraphic({
      key: item.key || item.url || 'missing',
      url: item.url,
      width,
      height,
      color: item.fallbackColor || this.fallbackColor,
      error
    });

    return {
      key: item.key || item.url,
      url: item.url,
      texture: null,
      displayObject,
      fallback: true,
      error
    };
  }

  _createFallbackGraphic(options) {
    if (this.graphicsFactory) return this.graphicsFactory(options);

    try {
      const graphic = new Graphics();
      graphic.rect(0, 0, options.width, options.height);
      graphic.fill({ color: options.color, alpha: 0.72 });
      graphic.rect(0, 0, options.width, options.height);
      graphic.stroke({ color: 0xffffff, width: 1, alpha: 0.9 });
      graphic.label = `missing:${options.key}`;
      graphic.omnicoreMissingPath = options.url || options.key;
      graphic.omnicoreDebugLabel = this.debug ? `Missing asset: ${options.url || options.key}` : '';
      return graphic;
    } catch {
      return {
        type: 'missing-texture',
        key: options.key,
        path: options.url || options.key,
        debugLabel: this.debug ? `Missing asset: ${options.url || options.key}` : '',
        width: options.width,
        height: options.height,
        color: options.color
      };
    }
  }
}

export default AssetLoader;
