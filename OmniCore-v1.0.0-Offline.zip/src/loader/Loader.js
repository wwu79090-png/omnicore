/**
 * Asset loader with manifest preflight, timeout, retry, and friendly errors.
 *
 * @example
 * const loader = new Loader({ timeout: 5000, retries: 1 });
 * const assets = await loader.loadBundle([
 *   { key: 'hero', url: '/assets/default/default-tilesheet.svg', type: 'blob' }
 * ]);
 */
export class FriendlyLoadError extends Error {
  constructor(message, item, cause) {
    super(message);
    this.name = 'FriendlyLoadError';
    this.item = item;
    this.cause = cause;
    this.friendlyMessage = `资源加载失败：${item?.key || item?.url || 'unknown'}，请检查网络或资源清单。`;
  }
}

export class Loader {
  constructor({ timeout = 5000, retries = 1, fetcher = globalThis.fetch?.bind(globalThis), onFriendlyError } = {}) {
    this.timeout = timeout;
    this.retries = retries;
    this.fetcher = fetcher;
    this.onFriendlyError = onFriendlyError;
    this.cache = new Map();
    this.inflight = new Map();
  }

  async preflightManifest(url = 'asset-manifest.json') {
    const manifest = await this._loadItem({ key: 'manifest', url, type: 'json' }, 0);
    if (!manifest || (!Array.isArray(manifest.assets) && !Array.isArray(manifest))) {
      throw new Error('asset-manifest.json must export an array or { assets: [] }.');
    }
    return manifest;
  }

  async loadBundle(items, options = {}) {
    const list = Array.isArray(items) ? items : items?.assets || [];
    const output = {};
    await Promise.all(
      list.map(async (item) => {
        output[this._cacheKey(item)] = await this._loadItem(item, options.retries ?? this.retries);
      })
    );
    return output;
  }

  async _loadItem(item, retriesLeft) {
    const key = this._cacheKey(item);
    if (this.cache.has(key)) return this.cache.get(key);
    if (this.inflight.has(key)) return this.inflight.get(key);

    const promise = this._loadAndCache(item, key, retriesLeft);
    this.inflight.set(key, promise);
    try {
      return await promise;
    } finally {
      this.inflight.delete(key);
    }
  }

  async _loadAndCache(item, key, retriesLeft) {
    try {
      const result = await this._fetchWithTimeout(item);
      this.cache.set(key, result);
      return result;
    } catch (error) {
      if (retriesLeft > 0) return this._loadAndCache(item, key, retriesLeft - 1);
      const friendly = new FriendlyLoadError(error.message, item, error);
      this.onFriendlyError?.(friendly);
      throw friendly;
    }
  }

  _cacheKey(item) {
    return item?.key || item?.url;
  }

  async _fetchWithTimeout(item) {
    if (!this.fetcher) throw new Error('No fetch implementation is available.');
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => controller?.abort(), item.timeout ?? this.timeout);
    try {
      const response = await this.fetcher(item.url, { signal: controller?.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status || 500}`);
      switch (item.type) {
        case 'json':
          return response.json();
        case 'arrayBuffer':
          return response.arrayBuffer();
        case 'blob':
          return response.blob();
        case 'text':
        case 'csv':
        default:
          return response.text();
      }
    } finally {
      clearTimeout(timer);
    }
  }
}

export default Loader;
