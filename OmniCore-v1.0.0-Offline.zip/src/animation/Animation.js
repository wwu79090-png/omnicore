/**
 * SpriteSheet frame animation controller.
 *
 * Frames can be an array or a map of animation names to arrays. Each frame is
 * written to `sprite.frame` and `sprite.texture` so existing Sprite rendering
 * paths can consume it.
 *
 * @example
 * const animation = new Animation(sprite, { run: ['run-0', 'run-1'] }, { frameRate: 12 });
 * animation.play('run');
 * scene.add(sprite.addAnimation(animation));
 */
export class Animation {
  constructor(sprite, spriteSheet, { frameRate = 12, loop = true } = {}) {
    this.sprite = sprite;
    this.spriteSheet = Array.isArray(spriteSheet) ? { default: spriteSheet } : spriteSheet;
    this.frameRate = frameRate;
    this.loop = loop;
    this.current = null;
    this.frameIndex = 0;
    this.elapsed = 0;
    this.playing = false;
  }

  play(name = 'default') {
    if (!this.spriteSheet[name]) throw new Error(`Animation "${name}" is not defined.`);
    this.current = name;
    this.frameIndex = 0;
    this.elapsed = 0;
    this.playing = true;
    this._applyFrame();
    return this;
  }

  stop() {
    this.playing = false;
    return this;
  }

  update(delta) {
    if (!this.playing || !this.current) return this;
    const frames = this.spriteSheet[this.current];
    const frameMs = 1000 / this.frameRate;
    const deltaMs = delta <= 10 ? delta * 1000 : delta;
    this.elapsed += deltaMs;

    while (this.elapsed >= frameMs && this.playing) {
      this.elapsed -= frameMs;
      this.frameIndex += 1;
      if (this.frameIndex >= frames.length) {
        if (this.loop) this.frameIndex = 0;
        else {
          this.frameIndex = frames.length - 1;
          this.stop();
        }
      }
      this._applyFrame();
    }
    return this;
  }

  _applyFrame() {
    const frame = this.spriteSheet[this.current][this.frameIndex];
    this.sprite.frame = frame;
    this.sprite.texture = frame;
  }
}

export default Animation;
