/**
 * JSON-based Event Sheet runtime inspired by Construct 3 and GDevelop.
 *
 * Events execute from top to bottom. Each event has `conditions` and `actions`.
 *
 * @example
 * const sheet = EventSheet.parse({
 *   events: [{ conditions: [{ op: 'equals', left: 'state.score', right: 3 }],
 *   actions: [{ op: 'set', target: 'state.win', value: true }] }]
 * });
 * sheet.run({ state: { score: 3 } });
 */
function getPath(target, path) {
  return String(path)
    .split('.')
    .reduce((value, key) => (value == null ? undefined : value[key]), target);
}

function setPath(target, path, value) {
  const parts = String(path).split('.');
  const key = parts.pop();
  const owner = parts.reduce((object, part) => {
    if (!object[part]) object[part] = {};
    return object[part];
  }, target);
  owner[key] = value;
}

function resolveValue(value, runtime) {
  if (value && typeof value === 'object' && '$path' in value) return getPath(runtime, value.$path);
  return value;
}

export class EventSheet {
  constructor(events = []) {
    this.events = events;
  }

  static parse(json, { includeResolver } = {}) {
    const events = [];
    for (const event of json.events || []) {
      if (event.include && includeResolver) {
        events.push(...EventSheet.parse(includeResolver(event.include), { includeResolver }).events);
      } else {
        events.push(event);
      }
    }
    return new EventSheet(events);
  }

  run(runtime) {
    for (const event of this.events) {
      if (this._conditionsPass(event.conditions || [], runtime)) {
        this._runActions(event.actions || [], runtime);
      }
    }
  }

  _conditionsPass(conditions, runtime) {
    return conditions.every((condition) => {
      const left = getPath(runtime, condition.left);
      const right = resolveValue(condition.right, runtime);
      switch (condition.op) {
        case 'equals':
          return left === right;
        case 'notEquals':
          return left !== right;
        case 'gt':
          return left > right;
        case 'gte':
          return left >= right;
        case 'lt':
          return left < right;
        case 'lte':
          return left <= right;
        case 'truthy':
          return Boolean(left);
        case 'falsy':
          return !left;
        default:
          throw new Error(`Unsupported event condition: ${condition.op}`);
      }
    });
  }

  _runActions(actions, runtime) {
    for (const action of actions) {
      switch (action.op) {
        case 'set':
          setPath(runtime, action.target, resolveValue(action.value, runtime));
          break;
        case 'inc':
          setPath(runtime, action.target, (getPath(runtime, action.target) || 0) + resolveValue(action.value, runtime));
          break;
        case 'emit': {
          const payload = { event: action.event, payload: resolveValue(action.payload, runtime) };
          if (typeof runtime.emit === 'function') runtime.emit(payload.event, payload.payload);
          else {
            runtime.events = runtime.events || [];
            runtime.events.push(payload);
          }
          break;
        }
        case 'call':
          runtime.actions?.[action.name]?.(runtime, action);
          break;
        default:
          throw new Error(`Unsupported event action: ${action.op}`);
      }
    }
  }
}

export default EventSheet;
