/**
 * Scene and Sprite primitives.
 *
 * Scene mirrors Phaser's small lifecycle surface while keeping plugins explicit.
 * Sprite supports Cocos-style `addComponent()` without bringing an editor runtime.
 *
 * @example
 * const scene = new Scene('play');
 * const hero = scene.add(new Sprite('hero.png'));
 * hero.addComponent(class Health { constructor(owner) { this.owner = owner; } });
 */
class ComponentHost {
  constructor() {
    this.components = [];
  }

  addComponent(Component, options = {}) {
    const component = typeof Component === 'function' ? new Component(this, options) : Component;
    component.owner = component.owner || this;
    component.node = component.node || this;
    this.components.push(component);
    component.onAdd?.(this, options);
    component.onLoad?.();
    return component;
  }

  getComponent(Component) {
    return this.components.find((component) => component instanceof Component || component.type === Component);
  }

  removeComponent(component) {
    const index = this.components.indexOf(component);
    if (index >= 0) {
      component.onRemove?.();
      this.components.splice(index, 1);
    }
  }

  updateComponents(delta, time) {
    for (const component of this.components) component.update?.(delta, time);
  }

  destroyComponents() {
    for (const component of [...this.components]) {
      component.onDestroy?.();
    }
    this.components.length = 0;
  }
}

export class Sprite extends ComponentHost {
  constructor(texture, options = {}) {
    super();
    this.type = 'sprite';
    this.texture = texture;
    this.x = options.x ?? 0;
    this.y = options.y ?? 0;
    this.width = options.width ?? 32;
    this.height = options.height ?? 32;
    this.alpha = options.alpha ?? 1;
    this.scaleX = options.scaleX ?? 1;
    this.scaleY = options.scaleY ?? 1;
    this.rotation = options.rotation ?? 0;
    this.anchor = options.anchor ?? { x: 0, y: 0 };
    this.visible = options.visible ?? true;
    this.zIndex = options.zIndex ?? 0;
    this.displayObject = null;
    this.animations = [];
  }

  addAnimation(animation) {
    this.animations.push(animation);
    return animation;
  }

  update(delta, time) {
    this.updateComponents(delta, time);
    for (const animation of this.animations) animation.update(delta);
  }

  render(ctx) {
    if (!this.visible || !ctx) return;
    ctx.save();
    ctx.globalAlpha = this.alpha;
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);
    ctx.scale(this.scaleX, this.scaleY);
    const drawX = -this.anchor.x * this.width;
    const drawY = -this.anchor.y * this.height;
    if (this.texture instanceof HTMLImageElement || this.texture instanceof HTMLCanvasElement) {
      ctx.drawImage(this.texture, drawX, drawY, this.width, this.height);
    } else {
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(drawX, drawY, this.width, this.height);
      ctx.fillStyle = '#0f172a';
      ctx.font = '10px sans-serif';
      ctx.fillText(String(this.texture ?? 'sprite'), drawX + 4, drawY + 16);
    }
    ctx.restore();
  }

  destroy() {
    this.destroyComponents();
    for (const animation of this.animations) animation.stop?.();
    this.animations.length = 0;
    this.displayObject?.destroy?.({ children: true, texture: false, textureSource: false });
    this.displayObject = null;
  }
}

export class Scene extends ComponentHost {
  constructor(name, options = {}) {
    super();
    this.name = name;
    this.children = [];
    this.resources = new Set();
    this.created = false;
    this.active = true;
    this.visible = true;
    this.options = options;
    this.game = null;
    this.input = null;
    this.camera = null;
    this.timer = null;
  }

  add(child) {
    child.parent = this;
    this.children.push(child);
    this.children.sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));
    return child;
  }

  remove(child) {
    const index = this.children.indexOf(child);
    if (index >= 0) this.children.splice(index, 1);
  }

  init() {}

  preload() {}

  create() {}

  update(delta, time) {
    this.updateComponents(delta, time);
    for (const child of this.children) child.update?.(delta, time);
  }

  destroy() {
    for (const child of [...this.children]) child.destroy?.();
    for (const resource of this.resources) resource.destroy?.();
    this.destroyComponents();
    this.children.length = 0;
    this.resources.clear();
    this.active = false;
  }
}

export default Scene;
