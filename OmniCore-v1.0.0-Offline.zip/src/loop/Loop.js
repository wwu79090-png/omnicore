/**
 * Fixed-step requestAnimationFrame loop.
 *
 * Locks updates to 60 FPS, reports delta/interpolation, and pauses/resumes on
 * page visibility changes. The internal ticker is intentionally not exposed.
 *
 * @example
 * const loop = new Loop();
 * loop.subscribe((dt, time, alpha) => scene.update(dt, time, alpha));
 * loop.start();
 */
export class Loop {
  constructor({
    fps = 60,
    autoPause = true,
    stallMs = 120,
    stallFrameThreshold = 3,
    onStall = null
  } = {}) {
    this.fps = fps;
    this.frameMs = 1000 / fps;
    this.autoPause = autoPause;
    this.stallMs = stallMs;
    this.stallFrameThreshold = stallFrameThreshold;
    this.onStall = onStall;
    this.slowFrameCount = 0;
    this.subscribers = new Set();
    this.running = false;
    this.paused = false;
    this.lastTime = 0;
    this.accumulator = 0;
    this.frameHandle = null;
    this.boundTick = (time) => this._tick(time);
    this.visibilityHandler = () => {
      if (document.hidden) this.pause();
      else this.resume();
    };
  }

  subscribe(handler) {
    this.subscribers.add(handler);
    return () => this.subscribers.delete(handler);
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.paused = false;
    this.lastTime = this._now();
    if (this.autoPause && typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', this.visibilityHandler);
    }
    this._schedule();
  }

  pause() {
    this.paused = true;
  }

  resume() {
    if (!this.running) return;
    this.paused = false;
    this.lastTime = this._now();
  }

  stop() {
    this.running = false;
    if (this.frameHandle != null) this._cancel(this.frameHandle);
    if (this.autoPause && typeof document !== 'undefined') {
      document.removeEventListener('visibilitychange', this.visibilityHandler);
    }
    this.frameHandle = null;
  }

  _tick(time) {
    if (!this.running) return;
    if (!this.paused) {
      const delta = Math.min(100, time - this.lastTime);
      this.accumulator += delta;
      while (this.accumulator >= this.frameMs) {
        const seconds = this.frameMs / 1000;
        const updateStart = this._now();
        for (const handler of this.subscribers) handler(seconds, time, this.accumulator / this.frameMs);
        this._detectStall(this._now() - updateStart);
        this.accumulator -= this.frameMs;
      }
      this.lastTime = time;
    }
    this._schedule();
  }

  _schedule() {
    this.frameHandle = this._raf(this.boundTick);
  }

  _raf(handler) {
    if (typeof requestAnimationFrame === 'function') return requestAnimationFrame(handler);
    return setTimeout(() => handler(this._now()), this.frameMs);
  }

  _cancel(handle) {
    if (typeof cancelAnimationFrame === 'function') cancelAnimationFrame(handle);
    else clearTimeout(handle);
  }

  _now() {
    return typeof performance !== 'undefined' ? performance.now() : Date.now();
  }

  _detectStall(updateMs) {
    if (updateMs <= this.stallMs) {
      this.slowFrameCount = 0;
      return;
    }
    this.slowFrameCount += 1;
    if (this.slowFrameCount < this.stallFrameThreshold) return;

    const payload = {
      updateMs,
      stallMs: this.stallMs,
      frames: this.slowFrameCount
    };
    this.stop();
    this.onStall?.(payload);
    console.error(`[OmniCore] Loop stopped after ${this.slowFrameCount} consecutive frames above ${this.stallMs}ms.`, payload);
  }
}

export default Loop;
