import { atom as nanoAtom } from 'nanostores';

function valueType(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  return typeof value;
}

/**
 * Nano Stores based global state registry.
 *
 * Renderer backends inject their current identity here so cross-backend state is
 * retained during experimental renderer switching.
 *
 * @example
 * const store = new Store({ score: 0 });
 * store.subscribe('score', (score) => uiScore.text = String(score));
 * store.injectBackend('pixi');
 */
export class Store {
  static pluginMarket = {
    cdn: '',
    fetcher: globalThis.fetch?.bind(globalThis),
    moduleLoader: (url) => import(url),
    installed: new Map()
  };

  constructor(initialState = {}, options = {}) {
    this.stores = new Map();
    this.debug = Boolean(options.debug);
    this.emergencyPatch = options.emergencyPatch || {};
    this.initialTypes = new Map();
    Object.entries(initialState).forEach(([key, value]) => this.atom(key, value));
  }

  atom(key, initialValue = null) {
    if (!this.stores.has(key)) {
      this.stores.set(key, nanoAtom(initialValue));
      this.initialTypes.set(key, valueType(initialValue));
    }
    return this.stores.get(key);
  }

  set(key, value) {
    this._warnTypeDrift(key, value);
    const patched = this._applyEmergencyPatch(key, value);
    this.atom(key).set(patched);
    return patched;
  }

  get(key) {
    return this.atom(key).get();
  }

  subscribe(key, listener) {
    return this.atom(key).subscribe(listener);
  }

  injectBackend(backend) {
    this.set('backend', backend);
    this.set('rendererInjectedAt', Date.now());
  }

  snapshot() {
    const result = {};
    for (const [key, store] of this.stores) result[key] = store.get();
    return result;
  }

  _warnTypeDrift(key, value) {
    if (!this.debug) return;
    const previousType = this.initialTypes.get(key);
    const nextType = valueType(value);
    if (previousType && previousType !== 'null' && nextType !== previousType) {
      console.warn(`[OmniCore] Store type mismatch for "${key}": expected ${previousType}, received ${nextType}.`);
    }
  }

  _applyEmergencyPatch(key, value) {
    const patch = this.emergencyPatch[key];
    if (!patch) return value;
    if (typeof patch === 'function') {
      const next = patch(value);
      if (next !== value) console.warn(`[OmniCore] Store emergencyPatch repaired "${key}".`);
      return next;
    }
    if (typeof value !== 'number' || value < patch.min || value > patch.max) {
      console.warn(`[OmniCore] Store emergencyPatch repaired "${key}".`);
      return patch.fallback;
    }
    return value;
  }

  static configurePluginMarket(options = {}) {
    Store.pluginMarket = {
      ...Store.pluginMarket,
      ...options,
      installed: Store.pluginMarket.installed
    };
    return Store.pluginMarket;
  }

  static async install(name, options = {}) {
    if (Store.pluginMarket.installed.has(name) && !options.force) {
      return Store.pluginMarket.installed.get(name);
    }

    const manifest = await Store._loadPluginManifest(name, options.version);
    Store._assertPluginManifest(manifest, name);
    const moduleUrl = Store._resolveModuleUrl(manifest);
    const pluginModule = await Store.pluginMarket.moduleLoader(moduleUrl, manifest);
    const plugin = pluginModule.default || pluginModule;
    const exports = {};
    const sandbox = Store._createPluginSandbox(manifest, exports);
    await plugin.install?.(sandbox, { manifest });

    const record = {
      name: manifest.name,
      version: manifest.version,
      manifest,
      exports,
      installedAt: Date.now()
    };
    Store.pluginMarket.installed.set(name, record);
    return record;
  }

  static getPlugin(name) {
    return Store.pluginMarket.installed.get(name) || null;
  }

  static registerPlugin(name, exports = {}, manifest = {}) {
    const record = {
      name,
      version: manifest.version || '0.0.0',
      manifest: { name, ...manifest },
      exports,
      installedAt: Date.now()
    };
    Store.pluginMarket.installed.set(name, record);
    return record;
  }

  static async _loadPluginManifest(name, version = 'latest') {
    const { fetcher } = Store.pluginMarket;
    if (!fetcher) throw new Error('Plugin market requires a fetcher.');
    const base = Store.pluginMarket.cdn.replace(/\/$/, '');
    const url = `${base}/${name}/${version}/plugin.json`;
    const response = await fetcher(url);
    if (!response.ok) throw new Error(`Plugin manifest load failed: ${name}`);
    return response.json();
  }

  static _assertPluginManifest(manifest, expectedName) {
    if (!manifest?.name || manifest.name !== expectedName) {
      throw new Error(`Plugin manifest name mismatch: expected ${expectedName}.`);
    }
    if (!manifest.version) throw new Error(`Plugin "${expectedName}" requires a version.`);
    if (!manifest.module) throw new Error(`Plugin "${expectedName}" requires a module entry.`);
    const permissions = manifest.permissions || [];
    const allowed = new Set(['events', 'store', 'renderer', 'assets']);
    const denied = permissions.filter((permission) => !allowed.has(permission));
    if (denied.length) throw new Error(`Plugin "${expectedName}" requests unsupported permissions: ${denied.join(', ')}`);
  }

  static _resolveModuleUrl(manifest) {
    if (/^https?:\/\//.test(manifest.module)) return manifest.module;
    return `${Store.pluginMarket.cdn.replace(/\/$/, '')}/${manifest.name}/${manifest.version}/${manifest.module}`;
  }

  static _createPluginSandbox(manifest, exports) {
    return Object.freeze({
      name: manifest.name,
      version: manifest.version,
      permissions: [...(manifest.permissions || [])],
      register(key, value) {
        if (key === manifest.name && value && typeof value === 'object' && !Array.isArray(value)) {
          Object.assign(exports, value);
          return value;
        }
        exports[key] = value;
        return value;
      }
    });
  }
}

export default Store;
