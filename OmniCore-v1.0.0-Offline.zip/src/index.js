import { Backend, BackendManager, Game as CoreGame, StorageManager, loadPhysics } from './core/OmniCore.js';
import Deprecation from './core/Deprecation.js';
import EventBus from './core/EventBus.js';
import Animation from './animation/Animation.js';
import Camera from './camera/Camera.js';
import Node from './node/Node.js';
import { Scene, Sprite } from './scene/Scene.js';
import SceneManager from './scene/SceneManager.js';
import InputManager from './input/InputManager.js';
import Tween from './tween/Tween.js';
import Timer from './timer/Timer.js';
import Vec2 from './math/Vec2.js';
import Rect from './math/Rect.js';
import Easing from './math/Easing.js';
import Store from './store/Store.js';
import Loader from './loader/Loader.js';
import AssetLoader from './loader/AssetLoader.js';
import PixiRenderer from './renderer/PixiRenderer.js';
import RendererManager from './renderer/RendererManager.js';
import WebGLContextManager from './renderer/WebGLContextManager.js';
import * as Filters from './renderer/Filters.js';
import Loop from './loop/Loop.js';
import Button from './ui/Button.js';
import UIElement from './ui/UIElement.js';
import PrefabManager from './prefab/PrefabManager.js';
import ObjectPool from './pool/ObjectPool.js';
import EventSheet from './data/EventSheet.js';
import DataTable from './data/DataTable.js';
import I18n from './data/I18n.js';
import { DB, Database } from './database/Database.js';
import AudioManager from './audio/AudioManager.js';
import NetManager from './net/NetManager.js';
import Inspector from './debug/Inspector.js';
import ApiQuickPanel from './debug/ApiQuickPanel.js';
import LiveInspector from './debug/LiveInspector.js';
import LogForwarder from './debug/LogForwarder.js';
import PerformanceMonitor from './debug/PerformanceMonitor.js';
import VersionDialog from './debug/VersionDialog.js';
import FeedbackWidget from './feedback/FeedbackWidget.js';
import EditorPlugin from './editor/EditorPlugin.js';
import AuthManager from './compliance/AuthManager.js';
import PlatformAdapter from './platform/PlatformAdapter.js';
import Dimension3D from './dimension3d/Dimension3D.js';
import { detectEnvironment, safeInitialize } from './core/Bootstrap.js';
import Timeline from './timeline/Timeline.js';
import VisualEventGraph from './visualgraph/VisualEventGraph.js';
import HotReload from './hotreload/HotReload.js';
import AIImporter from './importer/AIImporter.js';
import WorkerManager from './worker/WorkerManager.js';
import Kernel from './microkernel/Kernel.js';
import RendererAdapter from './microkernel/RendererAdapter.js';
import SplashScreen from './microkernel/SplashScreen.js';
import AudioAddon from './addons/Audio.js';
import CanvasRendererAddon from './addons/CanvasRenderer.js';
import PixiRendererAddon from './addons/PixiRenderer.js';
import LeanOmniCore, {
  Addons as LeanAddons,
  Core as LeanCore,
  createLeanRuntime
} from './lean/index.js';

/**
 * OmniCore public module entry.
 *
 * @example
 * import OmniCore from 'omnicore';
 * const game = await new OmniCore.Game({ renderer: 'pixi' }).init();
 * const scene = new OmniCore.Scene('menu');
 * scene.add(new OmniCore.Sprite('hero.png'));
 */
function resolveRuntimeConfig(config = {}) {
  if (Object.prototype.hasOwnProperty.call(config, 'platform') && config.platform !== 'auto') return config;
  const environment = detectEnvironment(globalThis);
  return {
    ...config,
    platform: environment.platform
  };
}

/**
 * Public Game wrapper.
 *
 * Keeps CoreGame behavior intact while adding optional headless runtime,
 * automatic platform override, and debug helper attachment from src/index.js.
 *
 * @example
 * const game = await new Game({ headless: true, autoStart: false }).init();
 */
class Game extends CoreGame {
  constructor(config = {}) {
    super(resolveRuntimeConfig(config));
    this.headless = Boolean(this.config.headless);
    this.liveInspector = null;
    this.apiQuickPanel = null;
    this.feedbackWidget = null;
    this.editor = null;
    this.logForwarder = null;
    this.versionDialog = null;
    this.store.debug = Boolean(this.config.debug);
    this.store.emergencyPatch = this.config.emergencyPatch || this.store.emergencyPatch;
    this.assetLoader.debug = Boolean(this.config.debug);
  }

  async init() {
    if (!this.headless) {
      await super.init();
      this._attachRuntimeExtensions();
      return this;
    }

    await safeInitialize('StorageManager', () => StorageManager.ensureEngineVersion({
      engineVersion: this.config.engineVersion,
      onVersionMismatch: this.hooks.onVersionMismatch,
      migrations: this.config.migrations
    }), null, this.logger);

    if (this.config.databaseSources) await this.database.load(this.config.databaseSources);
    this.scene = safeInitialize('SceneManager', () => new SceneManager(this), null, this.logger);
    safeInitialize('TimerSubscription', () => this.loop.subscribe((delta) => this.timer.update(delta)), null, this.logger);
    Backend.bind(this);
    this.initialized = true;
    this.destroyed = false;
    if (this.config.autoStart) this.start();
    this._attachRuntimeExtensions();
    return this;
  }

  destroy() {
    this._detachRuntimeExtensions();
    super.destroy();
  }

  _attachRuntimeExtensions() {
    if (this.config.debug) {
      this.liveInspector = this.liveInspector || new LiveInspector(this, this.config.liveInspector || {});
      this.liveInspector.attach();
      this.apiQuickPanel = this.apiQuickPanel || new ApiQuickPanel();
      this.apiQuickPanel.attach();
      if (this.config.logForwarder !== false) {
        const options = typeof this.config.logForwarder === 'object' ? this.config.logForwarder : {};
        this.logForwarder = this.logForwarder || new LogForwarder(options);
        this.logForwarder.attach();
      }
    }

    if (this.config.feedback) {
      const options = typeof this.config.feedback === 'object' ? this.config.feedback : {};
      this.feedbackWidget = this.feedbackWidget || new FeedbackWidget(this, options);
      this.feedbackWidget.attach();
    }

    if (this.config.editor) {
      const options = typeof this.config.editor === 'object' ? this.config.editor : {};
      this.editor = this.editor || new EditorPlugin(this, options);
      this.editor.attach();
    }

    const version = this.config.version || this.config.engineVersion || '0.1.0';
    if (this.config.showChangelog !== false && (this.config.changelog || this.config.version || this.config.engineVersion)) {
      this.versionDialog = this.versionDialog || new VersionDialog(this, {
        version,
        changelog: this.config.changelog || ''
      });
      this.versionDialog.showIfNeeded();
    }
  }

  _detachRuntimeExtensions() {
    this.liveInspector?.detach?.();
    this.apiQuickPanel?.detach?.();
    this.feedbackWidget?.detach?.();
    this.editor?.detach?.();
    this.logForwarder?.detach?.();
    this.versionDialog?.detach?.();
    this.liveInspector = null;
    this.apiQuickPanel = null;
    this.feedbackWidget = null;
    this.editor = null;
    this.logForwarder = null;
    this.versionDialog = null;
  }
}

const System = {
  Auth: new AuthManager()
};

const addonRegistry = new Map();

const GENEALOGY = Object.freeze({
  engine: 'OmniCore',
  author: 'OmniCore Open Engine Maintainers',
  philosophy: ['logic-driven-rendering', 'microkernel', 'native-interaction', 'graceful-degradation'],
  timestamp: new Date().toISOString(),
  proof: 'OmniCore.Genealogy() build watermark'
});

function Genealogy() {
  return { ...GENEALOGY };
}

function addon(name, plugin) {
  if (!name || !plugin) throw new Error('OmniCore.addon(name, plugin) requires both arguments.');
  addonRegistry.set(name, plugin);
  return plugin;
}

async function useAddon(name, context = {}) {
  const plugin = addonRegistry.get(name);
  if (!plugin) throw new Error(`OmniCore addon "${name}" is not registered.`);
  await plugin.init?.(OmniCore, context);
  return plugin;
}

async function disableAddon(name, context = {}) {
  const plugin = addonRegistry.get(name);
  await plugin?.destroy?.(context);
  return plugin || null;
}

const OmniCore = {
  Game,
  Genealogy,
  addon,
  useAddon,
  disableAddon,
  EventBus,
  Editor: EditorPlugin,
  Lean: LeanOmniCore,
  LeanCore,
  LeanAddons,
  createLeanRuntime,
  Node,
  Scene,
  Sprite,
  Tween,
  Input: InputManager,
  InputManager,
  Camera,
  Timer,
  Animation,
  UI: { Button, UIElement },
  Prefab: PrefabManager,
  Backend,
  Dimension3D,
  Deprecation,
  Store,
  install: (name, options) => Store.install(name, options),
  Loader,
  AssetLoader,
  Renderer: { PixiRenderer, Filters, WebGLContextManager, RendererManager },
  RendererManager,
  Loop,
  Math: { Vec2, Rect, Easing },
  Database,
  DB,
  Timeline,
  VisualEventGraph,
  HotReload,
  AIImporter,
  Worker: WorkerManager,
  WorkerManager,
  Kernel,
  RendererAdapter,
  SplashScreen,
  AudioAddon,
  CanvasRendererAddon,
  PixiRendererAddon,
  AudioManager,
  DataTable,
  I18n,
  EventSheet,
  ObjectPool,
  Storage: StorageManager,
  Net: NetManager,
  System,
  PlatformAdapter,
  ApiQuickPanel,
  FeedbackWidget,
  LiveInspector,
  LogForwarder,
  PerformanceMonitor,
  VersionDialog,
  detectEnvironment,
  safeInitialize,
  loadPhysics
};

export default OmniCore;
export {
  AudioManager,
  AudioAddon,
  AIImporter,
  Animation,
  ApiQuickPanel,
  AssetLoader,
  Backend,
  BackendManager,
  Button,
  Camera,
  CanvasRendererAddon,
  DataTable,
  Database,
  DB,
  Deprecation,
  Dimension3D,
  Easing,
  EditorPlugin,
  EventSheet,
  EventBus,
  FeedbackWidget,
  Genealogy,
  Game,
  HotReload,
  I18n,
  InputManager,
  Inspector,
  Kernel,
  LeanAddons,
  LeanCore,
  LeanOmniCore,
  LiveInspector,
  Loader,
  LogForwarder,
  Loop,
  NetManager,
  Node,
  ObjectPool,
  PerformanceMonitor,
  PixiRenderer,
  PixiRendererAddon,
  PlatformAdapter,
  PrefabManager,
  Rect,
  RendererAdapter,
  RendererManager,
  Scene,
  SceneManager,
  Sprite,
  SplashScreen,
  StorageManager,
  Store,
  System,
  Timer,
  Timeline,
  Tween,
  UIElement,
  VersionDialog,
  VisualEventGraph,
  Vec2,
  WebGLContextManager,
  WorkerManager,
  createLeanRuntime,
  addon,
  disableAddon,
  detectEnvironment,
  useAddon,
  safeInitialize,
  loadPhysics
};
