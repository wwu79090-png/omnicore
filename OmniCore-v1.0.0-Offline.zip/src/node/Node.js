/**
 * Hierarchical runtime node used by prefabs and data-driven scenes.
 *
 * @example
 * const root = new Node({ name: 'Root' });
 * root.addChild(new Node({ name: 'Enemy' }));
 * root.getChild('Enemy');
 */
export class Node {
  constructor({
    name = 'node',
    type = 'node',
    x = 0,
    y = 0,
    zIndex = 0,
    visible = true,
    props = {},
    children = []
  } = {}) {
    this.type = type;
    this.name = name;
    this.x = x;
    this.y = y;
    this.zIndex = zIndex;
    this.visible = visible;
    this.props = { ...props };
    this.parent = null;
    this.children = [];
    this.components = [];
    children.forEach((child) => this.addChild(child instanceof Node ? child : Node.fromJSON(child)));
  }

  addChild(node) {
    if (!node) throw new Error('Node.addChild requires a child node.');
    if (node.parent) node.parent.removeChild(node);
    node.parent = this;
    this.children.push(node);
    this.children.sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));
    return node;
  }

  add(node) {
    return this.addChild(node);
  }

  getChild(nameOrPath) {
    if (!nameOrPath) return null;
    const parts = String(nameOrPath).split('/').filter(Boolean);
    let current = this;
    for (const part of parts) {
      current = current.children.find((child) => child.name === part) || null;
      if (!current) return null;
    }
    return current;
  }

  removeChild(childOrName) {
    const child = typeof childOrName === 'string' ? this.getChild(childOrName) : childOrName;
    const index = this.children.indexOf(child);
    if (index === -1) return null;
    const [removed] = this.children.splice(index, 1);
    removed.parent = null;
    return removed;
  }

  traverse(visitor) {
    visitor(this);
    for (const child of this.children) child.traverse?.(visitor);
  }

  addComponent(Component, options = {}) {
    const component = typeof Component === 'function' ? new Component(this, options) : Component;
    component.owner = component.owner || this;
    component.node = component.node || this;
    this.components.push(component);
    component.onAdd?.(this, options);
    component.onLoad?.();
    return component;
  }

  update(delta, time) {
    for (const component of this.components) component.update?.(delta, time);
    for (const child of this.children) child.update?.(delta, time);
  }

  destroy() {
    for (const child of [...this.children]) child.destroy?.();
    for (const component of [...this.components]) component.onDestroy?.();
    this.children.length = 0;
    this.components.length = 0;
    this.parent = null;
  }

  toJSON() {
    return {
      type: this.type,
      name: this.name,
      x: this.x,
      y: this.y,
      zIndex: this.zIndex,
      visible: this.visible,
      props: { ...this.props },
      children: this.children.map((child) => child.toJSON?.() || child)
    };
  }

  static fromJSON(json = {}) {
    return new Node(json);
  }
}

export default Node;
