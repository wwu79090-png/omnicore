/**
 * Optional Web Audio addon for microkernel mode.
 */
export class AudioAddon {
  constructor({ AudioContextRef = globalThis.AudioContext || globalThis.webkitAudioContext } = {}) {
    this.name = 'audio';
    this.AudioContextRef = AudioContextRef;
    this.ctx = null;
    this.sounds = new Map();
  }

  init() {
    if (!this.AudioContextRef) throw new Error('Web Audio API is not available.');
    this.ctx = this.ctx || new this.AudioContextRef();
    return this;
  }

  async load(key, url, fetcher = globalThis.fetch?.bind(globalThis)) {
    if (!this.ctx) this.init();
    const response = await fetcher(url);
    if (!response.ok) throw new Error(`Audio load failed: ${url}`);
    const buffer = await response.arrayBuffer();
    const decoded = await this.ctx.decodeAudioData(buffer);
    this.sounds.set(key, decoded);
    return decoded;
  }

  play(key, loop = false) {
    const buffer = this.sounds.get(key);
    if (!buffer || !this.ctx) return null;
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = loop;
    source.connect(this.ctx.destination);
    source.start();
    return source;
  }

  destroy() {
    this.ctx?.close?.();
    this.ctx = null;
    this.sounds.clear();
  }
}

export default AudioAddon;
