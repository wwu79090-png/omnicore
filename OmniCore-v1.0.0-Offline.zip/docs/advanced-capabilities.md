# OmniCore Advanced Capabilities Migration

This document describes the optional capabilities added after the base OmniCore
runtime. All modules are opt-in and keep existing `Game`, `Scene`, `Sprite`,
`Prefab`, `Store`, and `Backend` APIs compatible.

## 1. Node Tree and Nested Prefabs

Use `type: "node"` in prefab JSON when you need a pure hierarchy object:

```js
const root = OmniCore.Prefab.instantiate({
  type: 'node',
  name: 'Root',
  children: [{ type: 'node', name: 'Enemy' }]
});

root.getChild('Enemy');
```

Nested overrides are path-based:

```js
OmniCore.Prefab.instantiate(prefab, 0, 0, {}, {
  'Enemy/Weapon': { props: { damage: 12 } }
});
```

Existing sprite, scene, and button prefabs continue to work.

## 2. RPG Database

Load JSON tables from `examples/config/items.json`, `enemies.json`,
`skills.json`, and `states.json`:

```js
await OmniCore.DB.load({
  items: '/config/items.json',
  enemies: '/config/enemies.json',
  skills: '/config/skills.json',
  states: '/config/states.json'
});

const potion = OmniCore.DB.get('items', 'potion');
```

Records must include an `id` field. Tables can be object maps or arrays.

## 3. Timeline

Use `Timeline` when animation should come from JSON instead of chained tweens:

```js
const timeline = new OmniCore.Timeline({
  targets: { hero },
  events: { spawn: (payload) => spawnEnemy(payload) }
});

timeline.load(timelineJson).play();
timeline.update(delta * 1000);
```

Timeline config supports `duration`, `loop`, `tracks`, keyframes, easing names,
and event hooks.

## 4. Content Pipeline

Run the pipeline from the project root:

```bash
npm run pipeline
```

The script scans `assets/`, emits `dist/assets/sprites.atlas`, converts MP3
entries to WebM when `ffmpeg` exists, and writes `dist/assets/asset-manifest.json`.
Without `ffmpeg`, audio bytes are copied to `.webm` so CI remains deterministic.

## 5. Visual Event Graph

`VisualEventGraph` is debug-only. Do not mount it in production:

```js
if (game.config.debug) {
  const graph = new OmniCore.VisualEventGraph({ debug: true });
  graph.attach(document.body);
}
```

Exported JSON can be converted to Event Sheet JSON with `toEventSheet()`.

## 6. Renderer Auto Fallback

`renderer: 'auto'` tries Pixi first and then Canvas:

```js
await new OmniCore.Game({ renderer: 'auto' }).init();
```

Explicit `pixi`, `canvas`, and `webgl` values are unchanged.

## 7. Hot Reload

Hot reload listens for JSON messages from a WebSocket:

```json
{ "type": "asset", "assetType": "image", "key": "hero", "url": "/hero.png" }
```

```json
{ "type": "config", "dbType": "items", "id": "potion", "data": { "price": 25 } }
```

Configure it only in dev builds:

```js
new OmniCore.Game({ hotReload: { url: 'ws://localhost:35729' } });
```

## 8. AI Importer

`AIImporter` accepts a natural language prompt and returns `Scene.json`.
Use an injected LLM-compatible fetcher in production tools:

```js
const sceneJson = await game.aiImporter.generateScene('maze with 3 monsters');
```

If no endpoint is available, the importer uses a deterministic local parser for
simple monster/chest prompts.

## 9. Worker Manager

Register expensive tasks and run them through `OmniCore.Worker`:

```js
game.worker.register('pathfind', OmniCore.WorkerManager.astar);
const path = await game.worker.run('pathfind', { start, goal, grid });
```

When Worker construction is unavailable, tasks run on the main thread.

## 10. Plugin Market Protocol

Configure a CDN and install plugins:

```js
OmniCore.Store.configurePluginMarket({ cdn: 'https://cdn.example.com/plugins' });
await OmniCore.install('weather');
```

Plugin manifests must include `name`, `version`, `module`, and optional
`permissions`. The sandbox exposes only `register()`, plugin identity, version,
and declared permissions.
