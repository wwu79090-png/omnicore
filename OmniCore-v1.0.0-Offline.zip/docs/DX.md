# OmniCore 开发者体验手册

OmniCore 的开发体验目标是：小项目能直接开跑，大项目能持续维护，出现问题时能快速定位和回滚。

## 调试

- `debug: true` 会启用性能面板、Live Inspector、F1 API 速查面板和移动端日志转发入口。
- Live Inspector 显示当前场景实体树，点击实体后可以直接修改 `x`、`y`、`scaleX`、`scaleY`，画面同步刷新。
- 按 `F1` 弹出常用 API 速查，覆盖 `Game`、`Scene`、`Sprite`、`Store`、`Renderer`、`Backend` 等高频方法。

```js
await new OmniCore.Game({
  parent: '#game',
  debug: true,
  feedback: true
}).init();
```

## 性能分析

- PerformanceMonitor 显示 FPS、渲染耗时、实体数量和内存信息。
- Loop 内置防卡死检测：连续 3 帧更新耗时超过 120ms 时会停止循环并输出定位信息。
- Store 在开发模式下会嗅探类型变化，发现与初始类型不一致时输出黄色警告。

## 热更新

`HotReload` 可以在开发期监听资源和配置变更。建议只用于本地调试，生产构建关闭。

```js
const game = await new OmniCore.Game({
  hotReload: { url: 'ws://localhost:35729' }
}).init();
```

## 真机日志

PC 端运行：

```bash
npm run log-server
```

手机端开启：

```js
new OmniCore.Game({
  debug: true,
  logForwarder: { url: 'ws://你的电脑IP:8787' }
});
```

控制台日志会通过 WebSocket 转发到 PC 终端。

## 备份保护

- `npm run snapshot -- --export snapshots/boss-room.json` 导出当前测试快照。
- `npm run snapshot -- --import snapshots/boss-room.json` 导入快照，便于快速跳转到指定测试场景。
- Storage 支持版本迁移脚本，读取旧版本存档时会先保留旧副本，再写入新结构。

## 发布前检查

```bash
npm run production-ready
npm run audit:assets
npm run dist:full
```

这些命令会分别输出上线审计报告、资源引用报告和完整离线包。
