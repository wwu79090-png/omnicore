# OmniCore 第一小时教程

本教程只使用当前仓库已经实现的功能：脚手架、默认素材、`Game`、`Scene`、`Sprite`、输入查询和 Canvas/Pixi 渲染。

## 1. 创建项目

```bash
npx create-omnicore-app my-first-game --template basic
cd my-first-game
npm install
npm run dev
```

脚手架会复制 `assets/default/` 到新项目，默认素材包含 16x16 玩家、草地、箱子和 NPC 像素块。

## 2. 修改初始化配置

打开 `src/main.js`，确认存在以下初始化代码：

```js
import OmniCore from 'omnicore';

const game = await new OmniCore.Game({
  parent: '#game',
  width: 640,
  height: 360,
  renderer: 'auto',
  debug: true
}).init();
```

`renderer: 'auto'` 会优先尝试 Pixi，失败后降级到 Canvas。`debug: true` 会打开性能面板、F1 API 速查和实体检查器。

## 3. 添加图像实体

```js
const scene = new OmniCore.Scene('play');
const player = scene.add(new OmniCore.Sprite('assets/default/default-tilesheet.svg', {
  x: 80,
  y: 80,
  width: 32,
  height: 32
}));

game.scene.register(scene);
await game.scene.push('play');
```

如果素材路径写错，debug 模式下 Loader 会生成红色缺失资源标记，并记录丢失路径。

## 4. 编写移动逻辑

```js
scene.update = (delta) => {
  const speed = 120 * delta;
  if (game.input?.keyboard.isDown('ArrowLeft')) player.x -= speed;
  if (game.input?.keyboard.isDown('ArrowRight')) player.x += speed;
  if (game.input?.keyboard.isDown('ArrowUp')) player.y -= speed;
  if (game.input?.keyboard.isDown('ArrowDown')) player.y += speed;
};
```

保存后刷新页面，方向键即可移动玩家。按 `F1` 可以打开 API 速查面板，右侧 Live Inspector 可以实时修改实体坐标。

## 5. 生成微信小游戏骨架

```bash
npx create-omnicore-app wechat-rpg --platform wechat --template rpg-mini
```

生成目录会包含 `project.config.json`、`game.json` 和 `wechat-adapter.js`。该适配层使用现有平台检测能力，不依赖未实现的编辑器功能。
